﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ECommerce.API.DTOs;
using ECommerce.API.Services.Interfaces;
using ECommerce.API.Helpers;
using System.Security.Claims;

namespace ECommerce.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class AddressController : ControllerBase
    {
        private readonly IAddressService _addressService;
        private int UserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

        public AddressController(IAddressService addressService)
        {
            _addressService = addressService;
        }

        [HttpGet]
        public async Task<ActionResult<ServiceResponse<List<AddressDTO>>>> GetAddresses()
        {
            var response = await _addressService.GetUserAddressesAsync(UserId);
            return Ok(response);
        }

        [HttpPost]
        public async Task<ActionResult<ServiceResponse<AddressDTO>>> CreateAddress([FromBody] CreateAddressDTO dto)
        {
            var response = await _addressService.CreateAddressAsync(UserId, dto);
            if (response.Success)
                return CreatedAtAction(nameof(GetAddresses), response);
            return BadRequest(response);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<ServiceResponse<AddressDTO>>> UpdateAddress(int id, [FromBody] AddressDTO dto)
        {
            var response = await _addressService.UpdateAddressAsync(UserId, id, dto);
            if (response.Success)
                return Ok(response);
            return BadRequest(response);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<ServiceResponse<bool>>> DeleteAddress(int id)
        {
            var response = await _addressService.DeleteAddressAsync(UserId, id);
            if (response.Success)
                return Ok(response);
            return NotFound(response);
        }

        [HttpPost("{id}/set-default")]
        public async Task<ActionResult<ServiceResponse<bool>>> SetDefaultAddress(int id)
        {
            var response = await _addressService.SetDefaultAddressAsync(UserId, id);
            if (response.Success)
                return Ok(response);
            return BadRequest(response);
        }
    }
}
