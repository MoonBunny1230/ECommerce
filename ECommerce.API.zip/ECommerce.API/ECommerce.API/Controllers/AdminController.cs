﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ECommerce.API.DTOs;
using ECommerce.API.Services.Interfaces;
using ECommerce.API.Helpers;

namespace ECommerce.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Admin")]
    public class AdminController : ControllerBase
    {
        private readonly IUserService _userService;
        private readonly IProductService _productService;
        private readonly IOrderService _orderService;
        private readonly IAdminService _adminService;

        public AdminController(
            IUserService userService,
            IProductService productService,
            IOrderService orderService,
            IAdminService adminService)
        {
            _userService = userService;
            _productService = productService;
            _orderService = orderService;
            _adminService = adminService;
        }

        [HttpGet("users")]
        public async Task<ActionResult<ServiceResponse<List<UserDTO>>>> GetAllUsers()
        {
            var response = await _adminService.GetAllUsersAsync();
            return Ok(response);
        }

        [HttpGet("orders")]
        public async Task<ActionResult<ServiceResponse<List<OrderDTO>>>> GetAllOrders()
        {
            var response = await _adminService.GetAllOrdersAsync();
            return Ok(response);
        }

        [HttpGet("products")]
        public async Task<ActionResult<ServiceResponse<List<MonthlySalesDTO>>>> GetAllProducts()
        {
            var response = await _productService.GetAllAsync();
            return Ok(response);
        }

        [HttpGet("products/low-stock")]
        public async Task<ActionResult<ServiceResponse<List<MonthlySalesDTO>>>> GetLowStockProducts()
        {
            var response = await _adminService.GetLowStockProductsAsync();
            return Ok(response);
        }

        [HttpPost("products")]
        public async Task<ActionResult<ServiceResponse<MonthlySalesDTO>>> CreateProduct([FromBody] MonthlySalesDTO productDto)
        {
            var response = await _productService.AddProductAsync(productDto);
            if (!response.Success) return BadRequest(response);
            return CreatedAtAction(nameof(GetAllProducts), new { id = response.Data!.Id }, response);
        }

        [HttpPut("products/{id}")]
        public async Task<ActionResult<ServiceResponse<MonthlySalesDTO>>> UpdateProduct(int id, [FromBody] UpdateProductDTO updateProductDTO)
        {
            var response = await _productService.UpdateAsync(id, updateProductDTO);
            if (!response.Success) return NotFound(response);
            return Ok(response);
        }

        [HttpDelete("products/{id}")]
        public async Task<ActionResult<ServiceResponse<bool>>> DeleteProduct(int id)
        {
            var response = await _productService.DeleteProductAsync(id);
            if (!response.Success) return NotFound(response);
            return Ok(response);
        }

        [HttpDelete("users/{id}")]
        public async Task<ActionResult<ServiceResponse<bool>>> DeleteUser(int id)
        {
            var response = await _userService.DeleteUserAsync(id);
            if (!response.Success) return NotFound(response);
            return Ok(response);
        }

        [HttpPost("discounts")]
        public async Task<ActionResult<ServiceResponse<bool>>> CreateDiscount([FromBody] DiscountDTO discountDto)
        {
            var response = await _adminService.CreateDiscountAsync(discountDto);
            if (!response.Success) return BadRequest(response);
            return Ok(response);
        }

        [HttpGet("analytics")]
        public async Task<ActionResult<ServiceResponse<AnalyticsDTO>>> GetAnalytics()
        {
            var response = await _adminService.GetSalesAnalyticsAsync();
            return Ok(response);
        }
    }
}