﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ECommerce.API.DTOs;
using ECommerce.API.Services.Interfaces;
using ECommerce.API.Helpers;

namespace ECommerce.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Admin")]
    public class AnalyticsController : ControllerBase
    {
        private readonly IAnalyticsService _analyticsService;

        public AnalyticsController(IAnalyticsService analyticsService)
        {
            _analyticsService = analyticsService;
        }

        [HttpGet("top-products")]
        public async Task<ActionResult<ServiceResponse<List<TopProductDTO>>>> GetTopProducts()
        {
            var response = await _analyticsService.GetTopSellingProductsAsync();
            return Ok(response);
        }

        [HttpGet("summary")]
        public async Task<ActionResult<ServiceResponse<AnalyticsDTO>>> GetSummary()
        {
            var response = await _analyticsService.GetSummaryAsync();
            return Ok(response);
        }
    }
}