﻿using ECommerce.API.DTOs;
using ECommerce.API.Helpers;
using ECommerce.API.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace ECommerce.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class CartController : ControllerBase
    {
        private readonly ICartService _cartService;
        private int UserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

        public CartController(ICartService cartService)
        {
            _cartService = cartService;
        }

        [HttpGet]
        public async Task<ActionResult<ServiceResponse<CartDTO>>> GetCart()
        {
            var response = await _cartService.GetCartByUserIdAsync(UserId);
            return Ok(response);
        }

        [HttpPost("items")]
        public async Task<ActionResult<ServiceResponse<CartDTO>>> AddItemToCart([FromBody] CartItemDTO cartItemDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var response = await _cartService.AddItemToCartAsync(UserId, cartItemDto);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }

        [HttpDelete("items/{id}")]
        public async Task<ActionResult<ServiceResponse<bool>>> RemoveItemFromCart(int id)
        {
            var response = await _cartService.RemoveItemFromCartAsync(UserId, id);
            if (response.Success)
            {
                return Ok(response);
            }
            return NotFound(response);
        }

        [HttpPut("items/{id}/quantity")]
        public async Task<ActionResult<ServiceResponse<CartDTO>>> UpdateCartItemQuantity(int id, [FromBody] UpdateQuantityDTO updateDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var response = await _cartService.UpdateItemQuantityAsync(UserId, id, updateDto.Quantity);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }

        [HttpDelete("clear")]
        public async Task<ActionResult<ServiceResponse<bool>>> ClearCart()
        {
            var response = await _cartService.ClearCartAsync(UserId);
            return Ok(response);
        }
    }

    public class UpdateQuantityDTO
    {
        [System.ComponentModel.DataAnnotations.Range(1, 100)]
        public int Quantity { get; set; }
    }
}