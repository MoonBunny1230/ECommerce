﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ECommerce.API.DTOs;
using ECommerce.API.Services.Interfaces;
using ECommerce.API.Helpers;

namespace ECommerce.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CategoryController : ControllerBase
    {
        private readonly ICategoryService _categoryService;

        public CategoryController(ICategoryService categoryService)
        {
            _categoryService = categoryService;
        }

        [HttpGet]
        public async Task<ActionResult<ServiceResponse<List<CategoryDTO>>>> GetAll()
        {
            var response = await _categoryService.GetAllAsync();
            return Ok(response);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ServiceResponse<CategoryDTO>>> GetById(int id)
        {
            var response = await _categoryService.GetByIdAsync(id);
            if (!response.Success)
                return NotFound(response);
            return Ok(response);
        }

        [HttpPost]
        [Authorize(Roles = "Admin,Manager")]
        public async Task<ActionResult<ServiceResponse<CategoryDTO>>> Create([FromBody] CreateCategoryDTO createCategoryDTO)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var response = await _categoryService.AddAsync(createCategoryDTO);
            if (!response.Success)
                return BadRequest(response);

            return CreatedAtAction(nameof(GetById), new { id = response.Data.Id }, response);
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Admin,Manager")]
        public async Task<ActionResult<ServiceResponse<CategoryDTO>>> Update(int id, [FromBody] CategoryDTO categoryDTO)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var response = await _categoryService.UpdateAsync(id, categoryDTO);
            if (!response.Success)
                return NotFound(response);

            return Ok(response);
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<ServiceResponse<bool>>> Delete(int id)
        {
            var response = await _categoryService.DeleteAsync(id);
            if (!response.Success)
                return BadRequest(response);

            return Ok(response);
        }

        [HttpGet("tree")]
        public async Task<ActionResult<ServiceResponse<List<CategoryDTO>>>> GetCategoryTree()
        {
            // This returns all categories with parent-child relationships
            var response = await _categoryService.GetAllAsync();
            return Ok(response);
        }

        [HttpGet("{id}/products")]
        public async Task<ActionResult<ServiceResponse<List<CategoryDTO>>>> GetCategoryProducts(int id)
        {
            // This would require ProductService to get products by category
            // For now, just return the category info
            var response = await _categoryService.GetByIdAsync(id);
            return Ok(response);
        }
    }
}