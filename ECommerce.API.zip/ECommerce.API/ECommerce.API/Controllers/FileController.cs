﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ECommerce.API.DTOs;
using ECommerce.API.Services.Interfaces;
using ECommerce.API.Helpers;

namespace ECommerce.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Admin,Manager")]
    public class FileController : ControllerBase
    {
        private readonly IFileService _fileService;
        private readonly IWebHostEnvironment _environment;

        public FileController(IFileService fileService, IWebHostEnvironment environment)
        {
            _fileService = fileService;
            _environment = environment;
        }

        [HttpPost("upload")]
        public async Task<ActionResult<ServiceResponse<string>>> UploadFile([FromForm] FileUploadResultDTO dto)
        {
            var response = await _fileService.UploadFileAsync(dto.File, "products");
            if (response.Success)
                return Ok(response);
            return BadRequest(response);
        }

        [HttpDelete("{fileName}")]
        public async Task<ActionResult<ServiceResponse<bool>>> DeleteFile(string fileName)
        {
            var response = await _fileService.DeleteFileAsync(fileName, "products");
            if (response.Success)
                return Ok(response);
            return NotFound(response);
        }

        [HttpGet("{fileName}")]
        public async Task<IActionResult> GetFile(string fileName)
        {
            var filePath = Path.Combine(_environment.WebRootPath, "uploads", "products", fileName);

            if (!System.IO.File.Exists(filePath))
                return NotFound();

            var contentType = GetContentType(fileName);
            var fileBytes = await System.IO.File.ReadAllBytesAsync(filePath);

            return File(fileBytes, contentType);
        }

        private string GetContentType(string fileName)
        {
            var extension = Path.GetExtension(fileName).ToLowerInvariant();
            return extension switch
            {
                ".jpg" or ".jpeg" => "image/jpeg",
                ".png" => "image/png",
                ".gif" => "image/gif",
                ".webp" => "image/webp",
                _ => "application/octet-stream"
            };
        }
    }
}
