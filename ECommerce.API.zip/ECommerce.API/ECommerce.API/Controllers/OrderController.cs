﻿using ECommerce.API.DTOs;
using ECommerce.API.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using ECommerce.API.Models.Enums;
using ECommerce.API.Helpers;

namespace ECommerce.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class OrdersController : ControllerBase
    {
        private readonly IOrderService _orderService;
        private int UserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

        public OrdersController(IOrderService orderService)
        {
            _orderService = orderService;
        }

        [HttpPost]
        public async Task<ActionResult<ServiceResponse<OrderDTO>>> PlaceOrder([FromBody] CreateOrderDTO? orderDto = null)
        {
            ServiceResponse<OrderDTO> response;

            if (orderDto != null)
            {
                response = await _orderService.PlaceOrderAsync(UserId, orderDto);
            }
            else
            {
                response = await _orderService.PlaceOrderAsync(UserId);
            }

            if (response.Success)
            {
                return CreatedAtAction(nameof(GetOrderById), new { id = response.Data!.Id }, response);
            }
            return BadRequest(response);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ServiceResponse<OrderDTO>>> GetOrderById(int id)
        {
            var response = await _orderService.GetUserOrderAsync(UserId, id);
            if (response.Success)
            {
                return Ok(response);
            }
            return NotFound(response);
        }

        [HttpGet]
        public async Task<ActionResult<ServiceResponse<List<OrderDTO>>>> GetUserOrders()
        {
            var response = await _orderService.GetUserOrdersAsync(UserId);
            return Ok(response);
        }

        [HttpPut("{id}/status")]
        [Authorize(Roles = "Admin,Manager")]
        public async Task<ActionResult<ServiceResponse<OrderDTO>>> UpdateOrderStatus(int id, [FromBody] UpdateOrderStatusDTO statusDto)
        {
            var response = await _orderService.UpdateOrderStatusAsync(id, statusDto.Status);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }

        // Admin only - get all orders
        [HttpGet("admin/all")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<ServiceResponse<List<OrderDTO>>>> GetAllOrders()
        {
            var response = await _orderService.GetAllOrdersAsync();
            return Ok(response);
        }
    }

    // Helper DTO for status updates
    public class UpdateOrderStatusDTO
    {
        public OrderStatus Status { get; set; }
    }
}