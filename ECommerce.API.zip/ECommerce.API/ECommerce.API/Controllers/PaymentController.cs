﻿using ECommerce.API.DTOs;
using ECommerce.API.Helpers;
using ECommerce.API.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace ECommerce.API.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class PaymentController : ControllerBase
{
    private readonly IPaymentService _paymentService;
    private readonly IOrderService _orderService;
    private int UserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    public PaymentController(IPaymentService paymentService, IOrderService orderService)
    {
        _paymentService = paymentService;
        _orderService = orderService;
    }

    [HttpPost("process")]
    public async Task<ActionResult<ServiceResponse<PaymentResultDTO>>> ProcessPayment([FromBody] PaymentRequestDTO request)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        // Verify that the order belongs to the current user
        var orderResponse = await _orderService.GetUserOrderAsync(UserId, request.OrderId);
        if (!orderResponse.Success)
            return NotFound(new ServiceResponse<PaymentResultDTO>
            {
                Success = false,
                Message = "შეკვეთა ვერ მოიძებნა"
            });

        var response = await _paymentService.ProcessPaymentAsync(request);

        if (response.Success && response.Data?.Success == true)
        {
            // Update order status to paid if payment successful
            await _orderService.UpdateOrderStatusAsync(request.OrderId, Models.Enums.OrderStatus.Processing);
            return Ok(response);
        }

        return BadRequest(response);
    }

    [HttpGet("status/{transactionId}")]
    public async Task<ActionResult<ServiceResponse<PaymentStatusDTO>>> GetPaymentStatus(string transactionId)
    {
        var response = await _paymentService.GetPaymentStatusAsync(transactionId);

        if (response.Success)
            return Ok(response);

        return NotFound(response);
    }

    [HttpPost("refund")]
    [Authorize(Roles = "Admin,Manager")]
    public async Task<ActionResult<ServiceResponse<PaginatedResultDTO>>> RefundPayment([FromBody] RefundRequestDTO request)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var response = await _paymentService.RefundPaymentAsync(request);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    [HttpGet("methods")]
    public ActionResult<ServiceResponse<List<string>>> GetSupportedPaymentMethods()
    {
        var methods = new List<string> { "Cash", "Card", "BankTransfer" };

        return Ok(new ServiceResponse<List<string>>
        {
            Data = methods,
            Success = true,
            Message = "ხელმისაწვდომი გადახდის მეთოდები"
        });
    }
}