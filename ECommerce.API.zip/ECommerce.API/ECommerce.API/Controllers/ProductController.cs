﻿using ECommerce.API.DTOs;
using ECommerce.API.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ECommerce.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductsController : ControllerBase
{
    private readonly IProductService _productService;

    public ProductsController(IProductService productService)
    {
        _productService = productService;
    }

    [HttpGet]
    public async Task<IActionResult> GetProducts([FromQuery] ProductFilterDTO filter)
    {
        var response = await _productService.GetProductsAsync(filter);
        return Ok(response);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetProductById(int id)
    {
        var response = await _productService.GetProductByIdAsync(id);
        if (!response.Success)
        {
            return NotFound(response);
        }
        return Ok(response);
    }

    [HttpPost]
    [Authorize(Roles = "Admin,Manager")]
    public async Task<IActionResult> CreateProduct([FromBody] CreateProductDTO createProductDTO)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        // Map CreateProductDTO to MonthlySalesDTO for service compatibility
        var productDto = new MonthlySalesDTO
        {
            Name = createProductDTO.Name,
            Description = createProductDTO.Description,
            Price = createProductDTO.Price,
            Stock = createProductDTO.StockQuantity,
            CategoryId = createProductDTO.CategoryId,
            Images = createProductDTO.Images
        };

        var response = await _productService.AddProductAsync(productDto);

        if (!response.Success)
            return BadRequest(response);

        return CreatedAtAction(nameof(GetProductById), new { id = response.Data!.Id }, response);
    }

    [HttpPut("{id}")]
    [Authorize(Roles = "Admin,Manager")]
    public async Task<IActionResult> UpdateProduct(int id, [FromBody] UpdateProductDTO updateProductDto)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var response = await _productService.UpdateAsync(id, updateProductDto);

        if (!response.Success)
            return NotFound(response);

        return Ok(response);
    }

    [HttpDelete("{id}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> DeleteProduct(int id)
    {
        var response = await _productService.DeleteProductAsync(id);

        if (!response.Success)
            return NotFound(response);

        return Ok(response);
    }

    [HttpGet("search")]
    public async Task<IActionResult> SearchProducts([FromQuery] string query, [FromQuery] int page = 1, [FromQuery] int pageSize = 12)
    {
        var filter = new ProductFilterDTO
        {
            SearchQuery = query,
            PageNumber = page,
            PageSize = pageSize
        };

        var response = await _productService.GetProductsAsync(filter);
        return Ok(response);
    }

    [HttpGet("category/{categoryId}")]
    public async Task<IActionResult> GetProductsByCategory(int categoryId, [FromQuery] int page = 1, [FromQuery] int pageSize = 12)
    {
        var filter = new ProductFilterDTO
        {
            CategoryId = categoryId,
            PageNumber = page,
            PageSize = pageSize
        };

        var response = await _productService.GetProductsAsync(filter);
        return Ok(response);
    }

    [HttpGet("featured")]
    public async Task<IActionResult> GetFeaturedProducts([FromQuery] int count = 8)
    {
        var filter = new ProductFilterDTO
        {
            PageNumber = 1,
            PageSize = count,
            SortBy = "rating",
            SortDesc = true
        };

        var response = await _productService.GetProductsAsync(filter);
        return Ok(response);
    }

    [HttpGet("latest")]
    public async Task<IActionResult> GetLatestProducts([FromQuery] int count = 8)
    {
        var filter = new ProductFilterDTO
        {
            PageNumber = 1,
            PageSize = count,
            SortBy = "date",
            SortDesc = true
        };

        var response = await _productService.GetProductsAsync(filter);
        return Ok(response);
    }

    [HttpGet("discounted")]
    public async Task<IActionResult> GetDiscountedProducts([FromQuery] int page = 1, [FromQuery] int pageSize = 12)
    {
        // This would need to be implemented in ProductService to filter by discounted products
        var filter = new ProductFilterDTO
        {
            PageNumber = page,
            PageSize = pageSize
        };

        var response = await _productService.GetProductsAsync(filter);

        // Filter discounted products on the client side for now
        // In a real implementation, this should be done in the service/database level
        return Ok(response);
    }
}