﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ECommerce.API.DTOs;
using ECommerce.API.Services.Interfaces;
using ECommerce.API.Helpers;
using System.Security.Claims;

namespace ECommerce.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class WishlistController : ControllerBase
    {
        private readonly IWishlistService _wishlistService;
        private int UserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

        public WishlistController(IWishlistService wishlistService)
        {
            _wishlistService = wishlistService;
        }

        [HttpGet]
        public async Task<ActionResult<ServiceResponse<List<WishlistDTO>>>> GetWishlist()
        {
            var response = await _wishlistService.GetUserWishlistAsync(UserId);
            return Ok(response);
        }

        [HttpPost("{productId}")]
        public async Task<ActionResult<ServiceResponse<bool>>> AddToWishlist(int productId)
        {
            var response = await _wishlistService.AddToWishlistAsync(UserId, productId);
            if (response.Success)
                return Ok(response);
            return BadRequest(response);
        }

        [HttpDelete("{productId}")]
        public async Task<ActionResult<ServiceResponse<bool>>> RemoveFromWishlist(int productId)
        {
            var response = await _wishlistService.RemoveFromWishlistAsync(UserId, productId);
            if (response.Success)
                return Ok(response);
            return NotFound(response);
        }

        [HttpGet("check/{productId}")]
        public async Task<ActionResult<ServiceResponse<bool>>> IsInWishlist(int productId)
        {
            var response = await _wishlistService.IsInWishlistAsync(UserId, productId);
            return Ok(response);
        }
    }
}