﻿namespace ECommerce.API.DTOs
{
    public class AddressDTO
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty; // "Home", "Office" etc
        public string FullName { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public string Street { get; set; } = string.Empty;
        public string City { get; set; } = string.Empty;
        public string Country { get; set; } = "საქართველო";
        public string PostalCode { get; set; } = string.Empty;
        public bool IsDefault { get; set; }
    }
}
