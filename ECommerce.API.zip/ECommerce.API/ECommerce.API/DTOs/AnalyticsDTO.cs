﻿using System.Collections.Generic;

namespace ECommerce.API.DTOs;

public class AnalyticsDTO
{
    public int TotalOrders { get; set; }
    public decimal TotalRevenue { get; set; }
    public int TotalProducts { get; set; }
    public int TotalUsers { get; set; }
    public int LowStockProducts { get; set; }
    public decimal MonthlyRevenue { get; set; }
    public int MonthlyOrders { get; set; }
    public List<TopProductDTO> TopProducts { get; set; } = new();
    public List<MonthlySalesDTO> MonthlySales { get; set; } = new();
}