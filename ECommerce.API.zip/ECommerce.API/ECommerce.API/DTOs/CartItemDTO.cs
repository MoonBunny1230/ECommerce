﻿using System.ComponentModel.DataAnnotations;

namespace ECommerce.API.DTOs;

public class CartItemDTO
{
    public int Id { get; set; }
    public int ProductId { get; set; }
    public string ProductName { get; set; } = string.Empty;
    public string ProductImage { get; set; } = string.Empty;
    public decimal Price { get; set; }
    [Range(1, 100)] public int Quantity { get; set; }
    public bool InStock { get; set; } = true;

}