﻿using System.ComponentModel.DataAnnotations;

namespace ECommerce.API.DTOs;

public class CategoryDTO
{
    public int Id { get; set; }
    [Required] public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string ImageUrl { get; set; } = string.Empty;
    public int? ParentId { get; set; }
    public int ProductCount { get; set; } = 0;

}