﻿using System.ComponentModel.DataAnnotations;

namespace ECommerce.API.DTOs
{
    public class CreateAddressDTO
    {
        [Required] public string Name { get; set; } = string.Empty;
        [Required] public string FullName { get; set; } = string.Empty;
        [Required] public string Phone { get; set; } = string.Empty;
        [Required] public string Street { get; set; } = string.Empty;
        [Required] public string City { get; set; } = string.Empty;
        [Required] public string Country { get; set; } = "საქართველო";
        public string PostalCode { get; set; } = string.Empty;
        public bool IsDefault { get; set; } = false;
    }
}
