﻿using System.ComponentModel.DataAnnotations;

namespace ECommerce.API.DTOs;

public class CreateCategoryDTO
{
    [Required] public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string ImageUrl { get; set; } = string.Empty;
    public int? ParentId { get; set; }
}