﻿using System.ComponentModel.DataAnnotations;

namespace ECommerce.API.DTOs
{
    public class CreateCommentDTO
    {
        [Required] public int ProductId { get; set; }
        [Required] public int UserId { get; set; }
        [Required] public string Text { get; set; } = string.Empty;
        [Range(1, 5)] public int Rating { get; set; }
    }
}
