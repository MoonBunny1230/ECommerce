﻿using System.ComponentModel.DataAnnotations;

namespace ECommerce.API.DTOs;

public class CreateOrderDTO
{
    [Required] public string ShippingAddress { get; set; } = string.Empty;
    [Required] public string PaymentMethod { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;

}