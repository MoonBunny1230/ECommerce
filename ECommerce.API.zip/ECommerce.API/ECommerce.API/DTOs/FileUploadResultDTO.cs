﻿namespace ECommerce.API.DTOs
{
    public class FileUploadResultDTO
    {
        public IFormFile File { get; set; } = null!; // ADDED THIS LINE
        public bool Success { get; set; }
        public string? FileUrl { get; set; }
        public string? FileName { get; set; }
        public string? ErrorMessage { get; set; }
    }
}
