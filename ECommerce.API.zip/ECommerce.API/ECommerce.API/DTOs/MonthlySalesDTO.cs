﻿using System.ComponentModel.DataAnnotations;

namespace ECommerce.API.DTOs;

public class MonthlySalesDTO
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public decimal Price { get; set; }
    public int Stock { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public int CategoryId { get; set; }
    public decimal? DiscountPercentage { get; set; }
    public DateTime? DiscountExpiresAt { get; set; }
    public string Images { get; set; } = string.Empty;
    public bool IsInWishlist { get; set; } = false;
    public double AverageRating { get; set; } = 0;
    public int ReviewCount { get; set; } = 0;
    public DateTime CreatedAt { get; set; }

    // Analytics specific fields
    public string Month { get; set; } = string.Empty;
    public decimal Revenue { get; set; }
    public int OrderCount { get; set; }
}