﻿namespace ECommerce.API.DTOs
{
    public class PaymentStatusDTO
    {
        public string TransactionId { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty; // Success, Failed, Pending
        public decimal Amount { get; set; }
        public DateTime ProcessedAt { get; set; }
    }
}
