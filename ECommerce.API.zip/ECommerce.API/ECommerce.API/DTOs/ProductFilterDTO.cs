﻿namespace ECommerce.API.DTOs;

public class ProductFilterDTO
{
    public int? CategoryId { get; set; }
    public decimal? MinPrice { get; set; }
    public decimal? MaxPrice { get; set; }
    public string? SearchQuery { get; set; }
    public string? SortBy { get; set; } = "name"; // name, price, rating, date, popularity
    public bool SortDesc { get; set; } = false;
    public int PageNumber { get; set; } = 1;
    public int PageSize { get; set; } = 12;

    // New filtering options
    public bool? HasDiscount { get; set; }
    public bool? InStock { get; set; }
    public double? MinRating { get; set; }
    public List<string>? Tags { get; set; }
    public List<int>? CategoryIds { get; set; } // Multiple categories
}