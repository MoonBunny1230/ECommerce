﻿using System.ComponentModel.DataAnnotations;

namespace ECommerce.API.DTOs
{
    public class RefundRequestDTO
    {
        public bool Success { get; set; }
        public string? RefundId { get; set; }
        public string TransactionId { get; set; } = string.Empty;
        public decimal RefundAmount { get; set; }
        public DateTime ProcessedAt { get; set; }
        public string? ErrorMessage { get; set; }
    }
}
