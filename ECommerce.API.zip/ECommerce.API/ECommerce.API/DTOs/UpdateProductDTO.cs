﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ECommerce.API.DTOs;

public class UpdateProductDTO : CreateProductDTO

{
    public decimal? DiscountPercentage { get; set; }
    public DateTime? DiscountExpiresAt { get; set; }

}