﻿using System.ComponentModel.DataAnnotations;

namespace ECommerce.API.DTOs;

public class UserDTO
{
    public int Id { get; set; }
    [Required] public string Name { get; set; } = string.Empty;
    [Required][EmailAddress] public string Email { get; set; } = string.Empty;
    public string Username { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public int OrderCount { get; set; } = 0;
    public decimal TotalSpent { get; set; } = 0;

}