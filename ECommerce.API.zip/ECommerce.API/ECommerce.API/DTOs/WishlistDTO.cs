﻿namespace ECommerce.API.DTOs;

public class WishlistDTO
{
    public int Id { get; set; }
    public int ProductId { get; set; }
    public string ProductName { get; set; } = string.Empty;
    public decimal Price { get; set; }
    public string Image { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public bool InStock { get; set; } = true;
    public decimal? DiscountPercentage { get; set; }
}