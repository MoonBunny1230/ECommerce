﻿using ECommerce.API.Models;
using ECommerce.API.Models.Enums;
using Microsoft.EntityFrameworkCore;

namespace ECommerce.API.Data;

public static class DatabaseSeeder
{
    public static void SeedData(ModelBuilder modelBuilder)
    {
        // Seed Categories
        modelBuilder.Entity<Category>().HasData(
            new Category { Id = 1, Name = "ელექტრონიკა", Description = "ელექტრონული მოწყობილობები და აქსესუარები", CreatedAt = DateTime.UtcNow },
            new Category { Id = 2, Name = "ტანსაცმელი", Description = "მამაკაცის და ქალის ტანსაცმელი", CreatedAt = DateTime.UtcNow },
            new Category { Id = 3, Name = "სახლი და ბაღი", Description = "საოჯახო ნივთები და ბაღის აქსესუარები", CreatedAt = DateTime.UtcNow },
            new Category { Id = 4, Name = "წიგნები", Description = "სხვადასხვა ჟანრის წიგნები", CreatedAt = DateTime.UtcNow },
            new Category { Id = 5, Name = "სპორტი", Description = "სპორტული ინვენტარი და აქსესუარები", CreatedAt = DateTime.UtcNow }
        );

        // Seed Users (Including Admin)
        modelBuilder.Entity<User>().HasData(
            new User
            {
                Id = 1,
                Username = "admin",
                Email = "admin@ecommerce.ge",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("admin123"),
                UserRole = UserRole.Admin,
                Name = "სისტემის ადმინისტრატორი",
                CreatedAt = DateTime.UtcNow
            },
            new User
            {
                Id = 2,
                Username = "manager",
                Email = "manager@ecommerce.ge",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("manager123"),
                UserRole = UserRole.Manager,
                Name = "მენეჯერი",
                CreatedAt = DateTime.UtcNow
            },
            new User
            {
                Id = 3,
                Username = "customer",
                Email = "customer@example.com",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("customer123"),
                UserRole = UserRole.Customer,
                Name = "ტესტური მომხმარებელი",
                CreatedAt = DateTime.UtcNow
            }
        );

        // Seed Products
        modelBuilder.Entity<Product>().HasData(
            new Product
            {
                Id = 1,
                Name = "iPhone 15 Pro",
                Description = "ახალი iPhone 15 Pro უახლესი ტექნოლოგიებით",
                Price = 2499.99m,
                StockQuantity = 25,
                CategoryId = 1,
                Status = ProductStatus.Active,
                Images = "/uploads/products/iphone15.jpg",
                CreatedAt = DateTime.UtcNow
            },
            new Product
            {
                Id = 2,
                Name = "Samsung Galaxy S24",
                Description = "Samsung-ის ახალი ფლაგმანი მოდელი",
                Price = 2199.99m,
                StockQuantity = 30,
                CategoryId = 1,
                Status = ProductStatus.Active,
                Images = "/uploads/products/galaxy-s24.jpg",
                CreatedAt = DateTime.UtcNow
            },
            new Product
            {
                Id = 3,
                Name = "კოსტუმი",
                Description = "კლასიკური მამაკაცის კოსტუმი",
                Price = 299.99m,
                StockQuantity = 15,
                CategoryId = 2,
                Status = ProductStatus.Active,
                Images = "/uploads/products/suit.jpg",
                CreatedAt = DateTime.UtcNow
            },
            new Product
            {
                Id = 4,
                Name = "ვარდის თესლი",
                Description = "ლამაზი ვარდების თესლები ბაღისთვის",
                Price = 15.99m,
                StockQuantity = 100,
                CategoryId = 3,
                Status = ProductStatus.Active,
                Images = "/uploads/products/rose-seeds.jpg",
                CreatedAt = DateTime.UtcNow
            },
            new Product
            {
                Id = 5,
                Name = "პროგრამირების სახელმძღვანელო",
                Description = "C# პროგრამირების სრული კურსი",
                Price = 45.50m,
                StockQuantity = 50,
                CategoryId = 4,
                Status = ProductStatus.Active,
                Images = "/uploads/products/csharp-book.jpg",
                CreatedAt = DateTime.UtcNow
            },
            new Product
            {
                Id = 6,
                Name = "ფეხბურთის ბურთი",
                Description = "პროფესიონალური ფეხბურთის ბურთი",
                Price = 89.99m,
                StockQuantity = 20,
                CategoryId = 5,
                Status = ProductStatus.Active,
                Images = "/uploads/products/football.jpg",
                CreatedAt = DateTime.UtcNow
            },
            new Product
            {
                Id = 7,
                Name = "MacBook Pro",
                Description = "Apple MacBook Pro M3 ჩიპით",
                Price = 3999.99m,
                StockQuantity = 10,
                CategoryId = 1,
                Status = ProductStatus.Active,
                Images = "/uploads/products/macbook-pro.jpg",
                DiscountPercentage = 10,
                DiscountExpiresAt = DateTime.UtcNow.AddMonths(1),
                CreatedAt = DateTime.UtcNow
            },
            new Product
            {
                Id = 8,
                Name = "ქალის პლატფორმა",
                Description = "მოდური ქალის ფეხსაცმელი",
                Price = 129.99m,
                StockQuantity = 2, // Low stock for testing alerts
                CategoryId = 2,
                Status = ProductStatus.Active,
                Images = "/uploads/products/womens-shoes.jpg",
                CreatedAt = DateTime.UtcNow
            }
        );

        // Seed Sample Order
        modelBuilder.Entity<Order>().HasData(
            new Order
            {
                Id = 1,
                UserId = 3, // customer
                Status = OrderStatus.Delivered,
                TotalAmount = 2499.99m,
                ShippingAddress = "თბილისი, რუსთაველის გამზირი 12",
                PaymentMethod = "Card",
                CreatedAt = DateTime.UtcNow.AddDays(-7),
                UpdatedAt = DateTime.UtcNow.AddDays(-5)
            }
        );

        // Seed Order Items
        modelBuilder.Entity<OrderItem>().HasData(
            new OrderItem
            {
                Id = 1,
                OrderId = 1,
                ProductId = 1, // iPhone 15 Pro
                Quantity = 1,
                UnitPrice = 2499.99m
            }
        );

        // Seed Stock Alert
        modelBuilder.Entity<StockAlert>().HasData(
            new StockAlert
            {
                Id = 1,
                ProductId = 8, // Low stock product
                MinimumStock = 5,
                IsActive = true,
                LastAlertSent = DateTime.UtcNow.AddHours(-25), // Allow alert to be sent again
                CreatedAt = DateTime.UtcNow
            }
        );

        // Seed Content
        modelBuilder.Entity<Content>().HasData(
            new Content
            {
                Id = 1,
                Title = "ჩვენ შესახებ",
                Body = "ჩვენ ვართ საქართველოს წამყვანი ელექტრონული კომერციის კომპანია...",
                Slug = "about-us",
                IsActive = true,
                CreatedAt = DateTime.UtcNow
            },
            new Content
            {
                Id = 2,
                Title = "მიწოდების პირობები",
                Body = "ჩვენ ვახორციელებთ მიწოდებას მთელ საქართველოში...",
                Slug = "delivery-terms",
                IsActive = true,
                CreatedAt = DateTime.UtcNow
            }
        );

        // Seed Comments
        modelBuilder.Entity<Comment>().HasData(
            new Comment
            {
                Id = 1,
                ProductId = 1, // iPhone 15 Pro
                UserId = 3, // customer
                UserName = "ტესტური მომხმარებელი",
                Text = "შესანიშნავი ტელეფონია! ძალიან მომწონს.",
                Rating = 5,
                CreatedAt = DateTime.UtcNow.AddDays(-3)
            },
            new Comment
            {
                Id = 2,
                ProductId = 2, // Galaxy S24
                UserId = 3, // customer  
                UserName = "ტესტური მომხმარებელი",
                Text = "კარგი ტელეფონია, მაგრამ ბატარეა უკეთესი შეიძლება ყოფილიყო.",
                Rating = 4,
                CreatedAt = DateTime.UtcNow.AddDays(-1)
            }
        );
    }
}