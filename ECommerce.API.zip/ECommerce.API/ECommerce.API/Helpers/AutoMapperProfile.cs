﻿using AutoMapper;
using ECommerce.API.DTOs;
using ECommerce.API.Models;

namespace ECommerce.API.Helpers;

public class AutoMapperProfile : Profile
{
    public AutoMapperProfile()
    {
        // Product mappings - FIXED
        CreateMap<Product, ProductDTO>()
            .ForMember(dest => dest.CategoryName, opt => opt.MapFrom(src => src.Category != null ? src.Category.Name : ""))
            .ForMember(dest => dest.Stock, opt => opt.MapFrom(src => src.StockQuantity))
            .ForMember(dest => dest.AverageRating, opt => opt.MapFrom(src => src.Comments.Any() ? src.Comments.Average(c => c.Rating) : 0))
            .ForMember(dest => dest.ReviewCount, opt => opt.MapFrom(src => src.Comments.Count));

        // Keep MonthlySalesDTO for backward compatibility with existing services
        CreateMap<Product, MonthlySalesDTO>()
            .ForMember(dest => dest.CategoryName, opt => opt.MapFrom(src => src.Category != null ? src.Category.Name : ""))
            .ForMember(dest => dest.Stock, opt => opt.MapFrom(src => src.StockQuantity));

        CreateMap<MonthlySalesDTO, Product>()
            .ForMember(dest => dest.Category, opt => opt.Ignore())
            .ForMember(dest => dest.StockQuantity, opt => opt.MapFrom(src => src.Stock));

        CreateMap<CreateProductDTO, Product>()
            .ForMember(dest => dest.Category, opt => opt.Ignore())
            .ForMember(dest => dest.StockQuantity, opt => opt.MapFrom(src => src.StockQuantity));

        CreateMap<UpdateProductDTO, Product>()
            .ForMember(dest => dest.Category, opt => opt.Ignore())
            .ForMember(dest => dest.StockQuantity, opt => opt.MapFrom(src => src.StockQuantity));

        // User mappings
        CreateMap<User, UserDTO>()
            .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Name ?? src.Username))
            .ForMember(dest => dest.Role, opt => opt.MapFrom(src => src.UserRole.ToString()));

        CreateMap<RegisterDTO, User>()
            .ForMember(dest => dest.Username, opt => opt.MapFrom(src => src.Username))
            .ForMember(dest => dest.PasswordHash, opt => opt.Ignore())
            .ForMember(dest => dest.UserRole, opt => opt.Ignore());

        // Category mappings
        CreateMap<Category, CategoryDTO>()
            .ForMember(dest => dest.ProductCount, opt => opt.MapFrom(src => src.Products.Count));

        CreateMap<CategoryDTO, Category>()
            .ForMember(dest => dest.Children, opt => opt.Ignore())
            .ForMember(dest => dest.Parent, opt => opt.Ignore())
            .ForMember(dest => dest.Products, opt => opt.Ignore());

        CreateMap<CreateCategoryDTO, Category>();

        // Order mappings
        CreateMap<Order, OrderDTO>()
            .ForMember(dest => dest.Status, opt => opt.MapFrom(src => src.Status.ToString()))
            .ForMember(dest => dest.CustomerName, opt => opt.MapFrom(src => src.User != null ? src.User.Name ?? src.User.Username : ""))
            .ForMember(dest => dest.Items, opt => opt.MapFrom(src => src.Items));

        CreateMap<OrderItem, OrderItemDTO>()
            .ForMember(dest => dest.ProductName, opt => opt.MapFrom(src => src.Product != null ? src.Product.Name : ""))
            .ForMember(dest => dest.ProductImage, opt => opt.MapFrom(src => src.Product != null ? src.Product.Images : ""));

        // Cart mappings
        CreateMap<Cart, CartDTO>()
            .ForMember(dest => dest.Items, opt => opt.MapFrom(src => src.Items));

        CreateMap<CartItem, CartItemDTO>()
            .ForMember(dest => dest.ProductName, opt => opt.MapFrom(src => src.Product != null ? src.Product.Name : ""))
            .ForMember(dest => dest.ProductImage, opt => opt.MapFrom(src => src.Product != null ? src.Product.Images : ""))
            .ForMember(dest => dest.Price, opt => opt.MapFrom(src => src.Product != null ? src.Product.Price : 0))
            .ForMember(dest => dest.InStock, opt => opt.MapFrom(src => src.Product != null && src.Product.StockQuantity > 0));

        // Comment mappings
        CreateMap<Comment, CommentDTO>();
        CreateMap<CommentDTO, Comment>()
            .ForMember(dest => dest.User, opt => opt.Ignore())
            .ForMember(dest => dest.Product, opt => opt.Ignore());

        CreateMap<CreateCommentDTO, Comment>();

        // Content mappings
        CreateMap<Content, ContentDTO>();
        CreateMap<ContentDTO, Content>();

        // Discount mappings
        CreateMap<Discount, DiscountDTO>()
            .ForMember(dest => dest.ProductName, opt => opt.MapFrom(src => src.Product != null ? src.Product.Name : ""));
        CreateMap<DiscountDTO, Discount>()
            .ForMember(dest => dest.Product, opt => opt.Ignore());

        // Wishlist mappings
        CreateMap<Wishlist, WishlistDTO>()
            .ForMember(dest => dest.ProductName, opt => opt.MapFrom(src => src.Product != null ? src.Product.Name : ""))
            .ForMember(dest => dest.Price, opt => opt.MapFrom(src => src.Product != null ? src.Product.Price : 0))
            .ForMember(dest => dest.Image, opt => opt.MapFrom(src => src.Product != null ? src.Product.Images : ""))
            .ForMember(dest => dest.InStock, opt => opt.MapFrom(src => src.Product != null && src.Product.StockQuantity > 0))
            .ForMember(dest => dest.DiscountPercentage, opt => opt.MapFrom(src => src.Product != null ? src.Product.DiscountPercentage : null));

        // Address mappings
        CreateMap<Address, AddressDTO>();
        CreateMap<AddressDTO, Address>()
            .ForMember(dest => dest.User, opt => opt.Ignore());
        CreateMap<CreateAddressDTO, Address>()
            .ForMember(dest => dest.User, opt => opt.Ignore());
    }
}