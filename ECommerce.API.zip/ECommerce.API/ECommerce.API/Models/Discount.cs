﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ECommerce.API.Models;

public class Discount
{
    public int Id { get; set; }

    public int ProductId { get; set; }

    [Range(1, 100)]
    public int Percentage { get; set; }

    public DateTime ExpiresAt { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    // Navigation Property
    public Product Product { get; set; } = null!;
}