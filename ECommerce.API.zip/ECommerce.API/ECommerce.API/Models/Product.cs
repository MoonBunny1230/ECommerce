﻿using ECommerce.API.Models.Enums;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ECommerce.API.Models;

public class Product
{
    public int Id { get; set; }

    [Required]
    public string Name { get; set; } = string.Empty;

    public string Description { get; set; } = string.Empty;

    [Column(TypeName = "decimal(18,2)")]
    public decimal Price { get; set; }

    public int StockQuantity { get; set; } // დარჩეს StockQuantity (DB-სთან მეხსიერება)

    public ProductStatus Status { get; set; } = ProductStatus.Active;

    public int CategoryId { get; set; }

    public string Images { get; set; } = string.Empty;

    [Column(TypeName = "decimal(18,2)")]
    public decimal? DiscountPercentage { get; set; }

    public DateTime? DiscountExpiresAt { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

    // Navigation Properties
    public Category Category { get; set; } = null!;
    public ICollection<CartItem> CartItems { get; set; } = new List<CartItem>();
    public ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
    public ICollection<Comment> Comments { get; set; } = new List<Comment>();
    public ICollection<Discount> Discounts { get; set; } = new List<Discount>();
}
