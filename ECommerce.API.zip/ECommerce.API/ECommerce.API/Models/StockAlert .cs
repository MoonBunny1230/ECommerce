﻿namespace ECommerce.API.Models;

public class StockAlert
{
    public int Id { get; set; }
    public int ProductId { get; set; }
    public int MinimumStock { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime LastAlertSent { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    // Navigation Property
    public Product Product { get; set; } = null!;
}