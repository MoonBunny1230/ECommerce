﻿using System.ComponentModel.DataAnnotations;

namespace ECommerce.API.Models;

public class Wishlist
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public int ProductId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    // Navigation Properties
    public User User { get; set; } = null!;
    public Product Product { get; set; } = null!;
}