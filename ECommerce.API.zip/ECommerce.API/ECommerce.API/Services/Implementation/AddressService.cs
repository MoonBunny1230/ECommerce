﻿using AutoMapper;
using ECommerce.API.Data;
using ECommerce.API.DTOs;
using ECommerce.API.Helpers;
using ECommerce.API.Models;
using ECommerce.API.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace ECommerce.API.Services.Implementation;

public class AddressService : IAddressService
{
    private readonly AppDbContext _context;
    private readonly IMapper _mapper;

    public AddressService(AppDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<ServiceResponse<List<AddressDTO>>> GetUserAddressesAsync(int userId)
    {
        var addresses = await _context.Addresses
            .Where(a => a.UserId == userId)
            .OrderByDescending(a => a.IsDefault)
            .ThenByDescending(a => a.CreatedAt)
            .ToListAsync();

        var addressDtos = _mapper.Map<List<AddressDTO>>(addresses);
        return new ServiceResponse<List<AddressDTO>> { Data = addressDtos, Success = true };
    }

    public async Task<ServiceResponse<AddressDTO>> CreateAddressAsync(int userId, CreateAddressDTO dto)
    {
        var address = new Address
        {
            UserId = userId,
            Name = dto.Name,
            FullName = dto.FullName,
            Phone = dto.Phone,
            Street = dto.Street,
            City = dto.City,
            Country = dto.Country,
            PostalCode = dto.PostalCode,
            IsDefault = dto.IsDefault,
            CreatedAt = DateTime.UtcNow
        };

        // If this is being set as default, unset other defaults
        if (dto.IsDefault)
        {
            var existingDefaults = await _context.Addresses
                .Where(a => a.UserId == userId && a.IsDefault)
                .ToListAsync();

            foreach (var existing in existingDefaults)
                existing.IsDefault = false;
        }

        _context.Addresses.Add(address);
        await _context.SaveChangesAsync();

        var result = _mapper.Map<AddressDTO>(address);
        return new ServiceResponse<AddressDTO>
        {
            Data = result,
            Success = true,
            Message = "მისამართი წარმატებით შეიქმნა"
        };
    }

    public async Task<ServiceResponse<AddressDTO>> UpdateAddressAsync(int userId, int addressId, AddressDTO dto)
    {
        var address = await _context.Addresses
            .FirstOrDefaultAsync(a => a.Id == addressId && a.UserId == userId);

        if (address == null)
            return new ServiceResponse<AddressDTO> { Success = false, Message = "მისამართი ვერ მოიძებნა" };

        address.Name = dto.Name;
        address.FullName = dto.FullName;
        address.Phone = dto.Phone;
        address.Street = dto.Street;
        address.City = dto.City;
        address.Country = dto.Country;
        address.PostalCode = dto.PostalCode;
        address.IsDefault = dto.IsDefault;

        if (dto.IsDefault)
        {
            var existingDefaults = await _context.Addresses
                .Where(a => a.UserId == userId && a.IsDefault && a.Id != addressId)
                .ToListAsync();

            foreach (var existing in existingDefaults)
                existing.IsDefault = false;
        }

        await _context.SaveChangesAsync();

        var result = _mapper.Map<AddressDTO>(address);
        return new ServiceResponse<AddressDTO>
        {
            Data = result,
            Success = true,
            Message = "მისამართი განახლდა"
        };
    }

    public async Task<ServiceResponse<bool>> DeleteAddressAsync(int userId, int addressId)
    {
        var address = await _context.Addresses
            .FirstOrDefaultAsync(a => a.Id == addressId && a.UserId == userId);

        if (address == null)
            return new ServiceResponse<bool> { Success = false, Message = "მისამართი ვერ მოიძებნა" };

        _context.Addresses.Remove(address);
        await _context.SaveChangesAsync();

        return new ServiceResponse<bool>
        {
            Data = true,
            Success = true,
            Message = "მისამართი წაიშალა"
        };
    }

    public async Task<ServiceResponse<bool>> SetDefaultAddressAsync(int userId, int addressId)
    {
        var address = await _context.Addresses
            .FirstOrDefaultAsync(a => a.Id == addressId && a.UserId == userId);

        if (address == null)
            return new ServiceResponse<bool> { Success = false, Message = "მისამართი ვერ მოიძებნა" };

        // Unset all defaults for this user
        var existingDefaults = await _context.Addresses
            .Where(a => a.UserId == userId && a.IsDefault)
            .ToListAsync();

        foreach (var existing in existingDefaults)
            existing.IsDefault = false;

        // Set new default
        address.IsDefault = true;
        await _context.SaveChangesAsync();

        return new ServiceResponse<bool>
        {
            Data = true,
            Success = true,
            Message = "ძირითადი მისამართი განახლდა"
        };
    }

    public async Task<ServiceResponse<AddressDTO>> GetDefaultAddressAsync(int userId)
    {
        var address = await _context.Addresses
            .FirstOrDefaultAsync(a => a.UserId == userId && a.IsDefault);

        if (address == null)
            return new ServiceResponse<AddressDTO> { Success = false, Message = "ძირითადი მისამართი ვერ მოიძებნა" };

        var result = _mapper.Map<AddressDTO>(address);
        return new ServiceResponse<AddressDTO> { Data = result, Success = true };
    }
}
