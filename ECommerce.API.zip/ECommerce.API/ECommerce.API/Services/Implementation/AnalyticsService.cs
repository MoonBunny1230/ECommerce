﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using ECommerce.API.Data;
using ECommerce.API.DTOs;
using ECommerce.API.Helpers;
using ECommerce.API.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace ECommerce.API.Services.Implementation;

public class AnalyticsService : IAnalyticsService
{
    private readonly AppDbContext _context;
    private readonly IMapper _mapper;

    public AnalyticsService(AppDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<ServiceResponse<List<TopProductDTO>>> GetTopSellingProductsAsync()
    {
        var response = new ServiceResponse<List<TopProductDTO>>();

        var topProducts = await _context.OrderItems
            .Include(oi => oi.Product)
            .GroupBy(oi => oi.ProductId)
            .OrderByDescending(g => g.Sum(oi => oi.Quantity))
            .Take(10)
            .Select(g => new TopProductDTO
            {
                ProductId = g.Key,
                ProductName = g.First().Product.Name,
                QuantitySold = g.Sum(oi => oi.Quantity)
            })
            .ToListAsync();

        response.Data = topProducts;
        return response;
    }

    public async Task<ServiceResponse<AnalyticsDTO>> GetSummaryAsync()
    {
        var response = new ServiceResponse<AnalyticsDTO>();

        var totalOrders = await _context.Orders.CountAsync();
        var totalRevenue = await _context.Orders.SumAsync(o => o.TotalAmount);

        var topProducts = await _context.OrderItems
            .Include(oi => oi.Product)
            .GroupBy(oi => oi.ProductId)
            .OrderByDescending(g => g.Sum(oi => oi.Quantity))
            .Take(5)
            .Select(g => new TopProductDTO
            {
                ProductId = g.Key,
                ProductName = g.First().Product.Name,
                QuantitySold = g.Sum(oi => oi.Quantity)
            })
            .ToListAsync();

        var analytics = new AnalyticsDTO
        {
            TotalOrders = totalOrders,
            TotalRevenue = totalRevenue,
            TopProducts = topProducts
        };

        response.Data = analytics;
        return response;
    }
}