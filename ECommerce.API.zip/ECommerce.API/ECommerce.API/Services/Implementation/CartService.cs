﻿using AutoMapper;
using ECommerce.API.Data;
using ECommerce.API.DTOs;
using ECommerce.API.Helpers;
using ECommerce.API.Models;
using ECommerce.API.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace ECommerce.API.Services.Implementation;

public class CartService : ICartService
{
    private readonly AppDbContext _context;
    private readonly IMapper _mapper;

    public CartService(AppDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<ServiceResponse<CartDTO>> GetCartAsync(int userId)
    {
        var response = new ServiceResponse<CartDTO>();

        var cart = await _context.Carts
            .Include(c => c.Items)
            .ThenInclude(ci => ci.Product)
            .FirstOrDefaultAsync(c => c.UserId == userId);

        if (cart == null)
        {
            cart = new Cart { UserId = userId };
            _context.Carts.Add(cart);
            await _context.SaveChangesAsync();
        }

        response.Data = _mapper.Map<CartDTO>(cart);
        return response;
    }

    public async Task<ServiceResponse<CartDTO>> GetCartByUserIdAsync(int userId)
    {
        return await GetCartAsync(userId);
    }

    public async Task<ServiceResponse<CartDTO>> AddItemAsync(int userId, CartItemDTO dto)
    {
        var response = new ServiceResponse<CartDTO>();

        var cart = await GetOrCreateCartAsync(userId);

        var existingItem = await _context.CartItems
            .FirstOrDefaultAsync(ci => ci.CartId == cart.Id && ci.ProductId == dto.ProductId);

        if (existingItem != null)
        {
            existingItem.Quantity += dto.Quantity;
        }
        else
        {
            var cartItem = new CartItem
            {
                CartId = cart.Id,
                ProductId = dto.ProductId,
                Quantity = dto.Quantity
            };
            _context.CartItems.Add(cartItem);
        }

        await _context.SaveChangesAsync();

        var updatedCart = await GetCartAsync(userId);
        response.Data = updatedCart.Data;
        response.Message = "პროდუქტი კალათაში დაემატა";
        return response;
    }

    public async Task<ServiceResponse<CartDTO>> AddItemToCartAsync(int userId, CartItemDTO dto)
    {
        return await AddItemAsync(userId, dto);
    }

    public async Task<ServiceResponse<CartDTO>> UpdateQuantityAsync(int userId, int itemId, int quantity)
    {
        var response = new ServiceResponse<CartDTO>();

        var cart = await _context.Carts
            .Include(c => c.Items)
            .FirstOrDefaultAsync(c => c.UserId == userId);

        if (cart == null)
        {
            response.Success = false;
            response.Message = "კალათა ვერ მოიძებნა";
            return response;
        }

        var item = cart.Items.FirstOrDefault(i => i.Id == itemId);
        if (item == null)
        {
            response.Success = false;
            response.Message = "ნივთი კალათაში ვერ მოიძებნა";
            return response;
        }

        if (quantity <= 0)
        {
            _context.CartItems.Remove(item);
        }
        else
        {
            item.Quantity = quantity;
        }

        await _context.SaveChangesAsync();

        var updatedCart = await GetCartAsync(userId);
        response.Data = updatedCart.Data;
        response.Message = "რაოდენობა განახლდა";
        return response;
    }

    public async Task<ServiceResponse<CartDTO>> UpdateItemQuantityAsync(int userId, int itemId, int quantity)
    {
        return await UpdateQuantityAsync(userId, itemId, quantity);
    }

    public async Task<ServiceResponse<bool>> RemoveItemAsync(int userId, int itemId)
    {
        var response = new ServiceResponse<bool>();

        var cart = await _context.Carts
            .Include(c => c.Items)
            .FirstOrDefaultAsync(c => c.UserId == userId);

        if (cart == null)
        {
            response.Success = false;
            response.Message = "კალათა ვერ მოიძებნა";
            return response;
        }

        var item = cart.Items.FirstOrDefault(i => i.Id == itemId);
        if (item == null)
        {
            response.Success = false;
            response.Message = "ნივთი კალათაში ვერ მოიძებნა";
            return response;
        }

        _context.CartItems.Remove(item);
        await _context.SaveChangesAsync();

        response.Data = true;
        response.Message = "ნივთი კალათიდან წაიშალა";
        return response;
    }

    public async Task<ServiceResponse<bool>> RemoveItemFromCartAsync(int userId, int itemId)
    {
        return await RemoveItemAsync(userId, itemId);
    }

    public async Task<ServiceResponse<bool>> ClearCartAsync(int userId)
    {
        var response = new ServiceResponse<bool>();

        var cart = await _context.Carts
            .Include(c => c.Items)
            .FirstOrDefaultAsync(c => c.UserId == userId);

        if (cart == null)
        {
            response.Success = false;
            response.Message = "კალათა ვერ მოიძებნა";
            return response;
        }

        _context.CartItems.RemoveRange(cart.Items);
        await _context.SaveChangesAsync();

        response.Data = true;
        response.Message = "კალათა გასუფთავდა";
        return response;
    }

    private async Task<Cart> GetOrCreateCartAsync(int userId)
    {
        var cart = await _context.Carts.FirstOrDefaultAsync(c => c.UserId == userId);

        if (cart == null)
        {
            cart = new Cart { UserId = userId };
            _context.Carts.Add(cart);
            await _context.SaveChangesAsync();
        }

        return cart;
    }
}