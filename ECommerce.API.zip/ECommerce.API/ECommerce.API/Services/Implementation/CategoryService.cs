﻿using AutoMapper;
using ECommerce.API.Data;
using ECommerce.API.DTOs;
using ECommerce.API.Helpers;
using ECommerce.API.Models;
using ECommerce.API.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace ECommerce.API.Services.Implementation;

public class CategoryService : ICategoryService
{
    private readonly AppDbContext _context;
    private readonly IMapper _mapper;

    public CategoryService(AppDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<ServiceResponse<List<CategoryDTO>>> GetAllAsync()
    {
        var response = new ServiceResponse<List<CategoryDTO>>();

        var categories = await _context.Categories
            .Include(c => c.Children)
            .Include(c => c.Parent)
            .ToListAsync();

        response.Data = _mapper.Map<List<CategoryDTO>>(categories);
        return response;
    }

    public async Task<ServiceResponse<CategoryDTO>> GetByIdAsync(int id)
    {
        var response = new ServiceResponse<CategoryDTO>();

        var category = await _context.Categories
            .Include(c => c.Children)
            .Include(c => c.Parent)
            .FirstOrDefaultAsync(c => c.Id == id);

        if (category == null)
        {
            response.Success = false;
            response.Message = "კატეგორია ვერ მოიძებნა";
            return response;
        }

        response.Data = _mapper.Map<CategoryDTO>(category);
        return response;
    }

    public async Task<ServiceResponse<CategoryDTO>> CreateAsync(CategoryDTO dto)
    {
        var response = new ServiceResponse<CategoryDTO>();

        var category = _mapper.Map<Category>(dto);
        category.CreatedAt = DateTime.UtcNow;

        _context.Categories.Add(category);
        await _context.SaveChangesAsync();

        response.Data = _mapper.Map<CategoryDTO>(category);
        response.Message = "კატეგორია შეიქმნა";
        return response;
    }

    public async Task<ServiceResponse<CategoryDTO>> AddAsync(CreateCategoryDTO dto)
    {
        var response = new ServiceResponse<CategoryDTO>();

        var category = new Category
        {
            Name = dto.Name,
            Description = dto.Description,
            CreatedAt = DateTime.UtcNow
        };

        _context.Categories.Add(category);
        await _context.SaveChangesAsync();

        response.Data = _mapper.Map<CategoryDTO>(category);
        response.Message = "კატეგორია შეიქმნა";
        return response;
    }

    public async Task<ServiceResponse<CategoryDTO>> UpdateAsync(int id, CategoryDTO dto)
    {
        var response = new ServiceResponse<CategoryDTO>();

        var category = await _context.Categories.FindAsync(id);
        if (category == null)
        {
            response.Success = false;
            response.Message = "კატეგორია ვერ მოიძებნა";
            return response;
        }

        _mapper.Map(dto, category);
        category.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();

        response.Data = _mapper.Map<CategoryDTO>(category);
        response.Message = "კატეგორია განახლდა";
        return response;
    }

    public async Task<ServiceResponse<bool>> DeleteAsync(int id)
    {
        var response = new ServiceResponse<bool>();

        var category = await _context.Categories.FindAsync(id);
        if (category == null)
        {
            response.Success = false;
            response.Message = "კატეგორია ვერ მოიძებნა";
            return response;
        }

        // Check if category has products
        var hasProducts = await _context.Products.AnyAsync(p => p.CategoryId == id);
        if (hasProducts)
        {
            response.Success = false;
            response.Message = "კატეგორია შეიცავს პროდუქტებს და ვერ წაიშლება";
            return response;
        }

        _context.Categories.Remove(category);
        await _context.SaveChangesAsync();

        response.Data = true;
        response.Message = "კატეგორია წაიშალა";
        return response;
    }
}