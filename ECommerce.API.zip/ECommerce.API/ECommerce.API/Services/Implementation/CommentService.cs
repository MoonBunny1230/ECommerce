﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using ECommerce.API.Data;
using ECommerce.API.DTOs;
using ECommerce.API.Helpers;
using ECommerce.API.Models;
using ECommerce.API.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace ECommerce.API.Services.Implementation;

public class CommentService : ICommentService
{
    private readonly AppDbContext _context;
    private readonly IMapper _mapper;

    public CommentService(AppDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<ServiceResponse<CommentDTO>> CreateCommentAsync(CreateCommentDTO dto)
    {
        var productExists = await _context.Products.AnyAsync(p => p.Id == dto.ProductId);
        if (!productExists)
            return new ServiceResponse<CommentDTO> { Success = false, Message = "Product not found" };

        var user = await _context.Users.FindAsync(dto.UserId);
        if (user == null)
            return new ServiceResponse<CommentDTO> { Success = false, Message = "User not found" };

        var comment = new Comment
        {
            ProductId = dto.ProductId,
            UserId = dto.UserId,
            Text = dto.Text,
            Rating = dto.Rating,
            UserName = user.Username,
            CreatedAt = DateTime.UtcNow
        };

        _context.Comments.Add(comment);
        await _context.SaveChangesAsync();

        var result = _mapper.Map<CommentDTO>(comment);
        return new ServiceResponse<CommentDTO> { Data = result, Message = "Comment created successfully" };
    }

    public async Task<ServiceResponse<CommentDTO>> AddCommentAsync(int userId, CommentDTO dto)
    {
        var createDto = new CreateCommentDTO
        {
            ProductId = dto.ProductId,
            UserId = userId,
            Text = dto.Text,
            Rating = dto.Rating
        };

        return await CreateCommentAsync(createDto);
    }

    public async Task<ServiceResponse<List<CommentDTO>>> GetCommentsByProductAsync(int productId)
    {
        var comments = await _context.Comments
            .Where(c => c.ProductId == productId)
            .Include(c => c.User)
            .OrderByDescending(c => c.CreatedAt)
            .ToListAsync();

        var dto = _mapper.Map<List<CommentDTO>>(comments);
        return new ServiceResponse<List<CommentDTO>> { Data = dto };
    }

    public async Task<ServiceResponse<List<CommentDTO>>> GetCommentsForProductAsync(int productId)
    {
        return await GetCommentsByProductAsync(productId);
    }

    public async Task<ServiceResponse<bool>> DeleteCommentAsync(int commentId, int userId)
    {
        var comment = await _context.Comments.FindAsync(commentId);
        if (comment == null || comment.UserId != userId)
            return new ServiceResponse<bool> { Success = false, Message = "Comment not found or unauthorized" };

        _context.Comments.Remove(comment);
        await _context.SaveChangesAsync();

        return new ServiceResponse<bool> { Data = true, Message = "Comment deleted" };
    }
}
