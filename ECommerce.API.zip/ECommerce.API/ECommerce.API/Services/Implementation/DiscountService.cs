﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using ECommerce.API.Data;
using ECommerce.API.DTOs;
using ECommerce.API.Helpers;
using ECommerce.API.Models;
using ECommerce.API.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace ECommerce.API.Services.Implementation;

public class DiscountService : IDiscountService
{
    private readonly AppDbContext _context;
    private readonly IMapper _mapper;

    public DiscountService(AppDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<ServiceResponse<DiscountDTO>> CreateAsync(DiscountDTO dto)
    {
        var product = await _context.Products.FindAsync(dto.ProductId);
        if (product == null)
            return new ServiceResponse<DiscountDTO> { Success = false, Message = "Product not found" };

        var discount = new Discount
        {
            ProductId = dto.ProductId,
            Percentage = dto.Percentage,
            ExpiresAt = dto.ExpiresAt
        };

        _context.Discounts.Add(discount);
        await _context.SaveChangesAsync();

        await _context.Entry(discount).Reference(d => d.Product).LoadAsync();

        var result = _mapper.Map<DiscountDTO>(discount);
        return new ServiceResponse<DiscountDTO> { Data = result, Message = "Discount created" };
    }

    public async Task<ServiceResponse<List<DiscountDTO>>> GetActiveDiscountsAsync()
    {
        var now = DateTime.UtcNow;
        var discounts = await _context.Discounts
            .Where(d => d.ExpiresAt > now)
            .Include(d => d.Product)
            .ToListAsync();

        var dto = _mapper.Map<List<DiscountDTO>>(discounts);
        return new ServiceResponse<List<DiscountDTO>> { Data = dto };
    }

    public async Task<ServiceResponse<bool>> RemoveAsync(int id)
    {
        var discount = await _context.Discounts.FindAsync(id);
        if (discount == null)
            return new ServiceResponse<bool> { Success = false, Message = "Discount not found" };

        _context.Discounts.Remove(discount);
        await _context.SaveChangesAsync();

        return new ServiceResponse<bool> { Data = true, Message = "Discount removed" };
    }
}
