﻿using System.Net;
using System.Net.Mail;
using ECommerce.API.Helpers;
using ECommerce.API.Services.Interfaces;

namespace ECommerce.API.Services.Implementation;

public class EmailService : IEmailService
{
    private readonly IConfiguration _configuration;
    private readonly ILogger<EmailService> _logger;

    public EmailService(IConfiguration configuration, ILogger<EmailService> logger)
    {
        _configuration = configuration;
        _logger = logger;
    }

    public async Task<ServiceResponse<bool>> SendEmailAsync(string toEmail, string subject, string body)
    {
        try
        {
            var emailEnabled = _configuration.GetValue<bool>("Email:EnableEmails", true);

            if (!emailEnabled)
            {
                _logger.LogInformation($"Email sending disabled. Would send to: {toEmail}, Subject: {subject}");
                return new ServiceResponse<bool>
                {
                    Data = true,
                    Success = true,
                    Message = "Email sending is disabled (test mode)"
                };
            }

            var smtpServer = _configuration["Email:SmtpServer"];
            var smtpPort = _configuration.GetValue<int>("Email:SmtpPort", 587);
            var smtpUsername = _configuration["Email:SmtpUsername"];
            var smtpPassword = _configuration["Email:SmtpPassword"];
            var fromEmail = _configuration["Email:FromEmail"];
            var fromName = _configuration["Email:FromName"];

            if (string.IsNullOrEmpty(smtpServer) || string.IsNullOrEmpty(smtpUsername) ||
                string.IsNullOrEmpty(smtpPassword) || string.IsNullOrEmpty(fromEmail))
            {
                _logger.LogWarning("Email configuration is incomplete. Simulating email send.");
                await SimulateEmailSendAsync(toEmail, subject, body);
                return new ServiceResponse<bool>
                {
                    Data = true,
                    Success = true,
                    Message = "Email simulated (configuration incomplete)"
                };
            }

            using var client = new SmtpClient(smtpServer, smtpPort)
            {
                EnableSsl = true,
                Credentials = new NetworkCredential(smtpUsername, smtpPassword)
            };

            var mailMessage = new MailMessage
            {
                From = new MailAddress(fromEmail, fromName),
                Subject = subject,
                Body = body,
                IsBodyHtml = false
            };

            mailMessage.To.Add(toEmail);

            await client.SendMailAsync(mailMessage);

            _logger.LogInformation($"Email sent successfully to: {toEmail}");

            return new ServiceResponse<bool>
            {
                Data = true,
                Success = true,
                Message = "ემაილი წარმატებით გაიგზავნა"
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Failed to send email to: {toEmail}");

            // In development, simulate success to not break the flow
            if (_configuration.GetValue<bool>("Email:SimulateOnError", true))
            {
                await SimulateEmailSendAsync(toEmail, subject, body);
                return new ServiceResponse<bool>
                {
                    Data = true,
                    Success = true,
                    Message = "Email simulated due to error"
                };
            }

            return new ServiceResponse<bool>
            {
                Data = false,
                Success = false,
                Message = $"ემაილის გაგზავნისას მოხდა შეცდომა: {ex.Message}"
            };
        }
    }

    public async Task<ServiceResponse<bool>> SendHtmlEmailAsync(string toEmail, string subject, string htmlBody)
    {
        try
        {
            var emailEnabled = _configuration.GetValue<bool>("Email:EnableEmails", true);

            if (!emailEnabled)
            {
                _logger.LogInformation($"HTML Email sending disabled. Would send to: {toEmail}, Subject: {subject}");
                return new ServiceResponse<bool>
                {
                    Data = true,
                    Success = true,
                    Message = "HTML Email sending is disabled (test mode)"
                };
            }

            var smtpServer = _configuration["Email:SmtpServer"];
            var smtpPort = _configuration.GetValue<int>("Email:SmtpPort", 587);
            var smtpUsername = _configuration["Email:SmtpUsername"];
            var smtpPassword = _configuration["Email:SmtpPassword"];
            var fromEmail = _configuration["Email:FromEmail"];
            var fromName = _configuration["Email:FromName"];

            if (string.IsNullOrEmpty(smtpServer) || string.IsNullOrEmpty(smtpUsername) ||
                string.IsNullOrEmpty(smtpPassword) || string.IsNullOrEmpty(fromEmail))
            {
                _logger.LogWarning("Email configuration is incomplete. Simulating HTML email send.");
                await SimulateEmailSendAsync(toEmail, subject, htmlBody);
                return new ServiceResponse<bool>
                {
                    Data = true,
                    Success = true,
                    Message = "HTML Email simulated (configuration incomplete)"
                };
            }

            using var client = new SmtpClient(smtpServer, smtpPort)
            {
                EnableSsl = true,
                Credentials = new NetworkCredential(smtpUsername, smtpPassword)
            };

            var mailMessage = new MailMessage
            {
                From = new MailAddress(fromEmail, fromName),
                Subject = subject,
                Body = htmlBody,
                IsBodyHtml = true
            };

            mailMessage.To.Add(toEmail);

            await client.SendMailAsync(mailMessage);

            _logger.LogInformation($"HTML Email sent successfully to: {toEmail}");

            return new ServiceResponse<bool>
            {
                Data = true,
                Success = true,
                Message = "HTML ემაილი წარმატებით გაიგზავნა"
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Failed to send HTML email to: {toEmail}");

            // In development, simulate success to not break the flow
            if (_configuration.GetValue<bool>("Email:SimulateOnError", true))
            {
                await SimulateEmailSendAsync(toEmail, subject, htmlBody);
                return new ServiceResponse<bool>
                {
                    Data = true,
                    Success = true,
                    Message = "HTML Email simulated due to error"
                };
            }

            return new ServiceResponse<bool>
            {
                Data = false,
                Success = false,
                Message = $"HTML ემაილის გაგზავნისას მოხდა შეცდომა: {ex.Message}"
            };
        }
    }

    private async Task SimulateEmailSendAsync(string toEmail, string subject, string body)
    {
        _logger.LogInformation("=== EMAIL SIMULATION ===");
        _logger.LogInformation($"To: {toEmail}");
        _logger.LogInformation($"Subject: {subject}");
        _logger.LogInformation($"Body: {body[..Math.Min(body.Length, 100)]}...");
        _logger.LogInformation("========================");

        // Simulate sending delay
        await Task.Delay(500);
    }
}