﻿using ECommerce.API.DTOs;
using ECommerce.API.Helpers;
using ECommerce.API.Services.Interfaces;

namespace ECommerce.API.Services.Implementation;

public class FileService : IFileService
{
    private readonly IWebHostEnvironment _environment;
    private readonly ILogger<FileService> _logger;

    public FileService(IWebHostEnvironment environment, ILogger<FileService> logger)
    {
        _environment = environment;
        _logger = logger;
    }

    public async Task<ServiceResponse<string>> UploadFileAsync(IFormFile file, string folder)
    {
        if (file == null || file.Length == 0)
            return new ServiceResponse<string> { Success = false, Message = "ფაილი არ არის არჩეული" };

        // Validate file type
        var allowedExtensions = new[] { ".jpg", ".jpeg", ".png", ".gif", ".webp" };
        var extension = Path.GetExtension(file.FileName).ToLowerInvariant();

        if (!allowedExtensions.Contains(extension))
            return new ServiceResponse<string> { Success = false, Message = "მხოლოდ სურათების ფაილები დაშვებულია" };

        // Validate file size (5MB max)
        if (file.Length > 5 * 1024 * 1024)
            return new ServiceResponse<string> { Success = false, Message = "ფაილის ზომა ძალიან დიდია (მაქს 5MB)" };

        try
        {
            // Create directory if it doesn't exist
            var uploadsPath = Path.Combine(_environment.WebRootPath, "uploads", folder);
            Directory.CreateDirectory(uploadsPath);

            // Generate unique filename
            var fileName = $"{Guid.NewGuid()}{extension}";
            var filePath = Path.Combine(uploadsPath, fileName);

            // Save file
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            return new ServiceResponse<string>
            {
                Data = $"/uploads/{folder}/{fileName}",
                Success = true,
                Message = "ფაილი წარმატებით ატვირთულია"
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error uploading file");
            return new ServiceResponse<string> { Success = false, Message = "ფაილის ატვირთვისას მოხდა შეცდომა" };
        }
    }

    public async Task<ServiceResponse<bool>> DeleteFileAsync(string fileName, string folder)
    {
        try
        {
            var filePath = Path.Combine(_environment.WebRootPath, "uploads", folder, fileName);

            if (File.Exists(filePath))
            {
                File.Delete(filePath);
                return new ServiceResponse<bool>
                {
                    Data = true,
                    Success = true,
                    Message = "ფაილი წარმატებით წაიშალა"
                };
            }

            return new ServiceResponse<bool> { Success = false, Message = "ფაილი ვერ მოიძებნა" };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting file");
            return new ServiceResponse<bool> { Success = false, Message = "ფაილის წაშლისას მოხდა შეცდომა" };
        }
    }

    public async Task<ServiceResponse<List<string>>> UploadMultipleFilesAsync(IFormFile[] files, string folder)
    {
        var uploadedFiles = new List<string>();
        var errors = new List<string>();

        foreach (var file in files)
        {
            var result = await UploadFileAsync(file, folder);
            if (result.Success && result.Data != null)
            {
                uploadedFiles.Add(result.Data);
            }
            else
            {
                errors.Add($"{file.FileName}: {result.Message}");
            }
        }

        return new ServiceResponse<List<string>>
        {
            Data = uploadedFiles,
            Success = uploadedFiles.Any(),
            Message = errors.Any() ? string.Join("; ", errors) : "ყველა ფაილი ატვირთულია"
        };
    }
}
