﻿using ECommerce.API.Data;
using ECommerce.API.Helpers;
using ECommerce.API.Models;
using ECommerce.API.Models.Enums;
using ECommerce.API.Services.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace ECommerce.API.Services.Implementation;

public class NotificationService : INotificationService
{
    private readonly AppDbContext _context;
    private readonly IEmailService _emailService;
    private readonly ILogger<NotificationService> _logger;
    private readonly IConfiguration _configuration;

    public NotificationService(
        AppDbContext context,
        IEmailService emailService,
        ILogger<NotificationService> logger,
        IConfiguration configuration)
    {
        _context = context;
        _emailService = emailService;
        _logger = logger;
        _configuration = configuration;
    }

    public async Task<ServiceResponse<bool>> CheckLowStockAsync()
    {
        try
        {
            var lowStockThreshold = _configuration.GetValue<int>("AppSettings:LowStockThreshold", 5);

            var lowStockProducts = await _context.Products
                .Include(p => p.Category)
                .Where(p => p.StockQuantity <= lowStockThreshold && p.Status == ProductStatus.Active)
                .ToListAsync();

            if (lowStockProducts.Any())
            {
                // Create or update stock alerts
                foreach (var product in lowStockProducts)
                {
                    var existingAlert = await _context.StockAlerts
                        .FirstOrDefaultAsync(sa => sa.ProductId == product.Id);

                    if (existingAlert == null)
                    {
                        var stockAlert = new StockAlert
                        {
                            ProductId = product.Id,
                            MinimumStock = lowStockThreshold,
                            IsActive = true,
                            LastAlertSent = DateTime.UtcNow,
                            CreatedAt = DateTime.UtcNow
                        };
                        _context.StockAlerts.Add(stockAlert);
                    }
                    else if (existingAlert.LastAlertSent < DateTime.UtcNow.AddHours(-24))
                    {
                        // Send alert only once per day
                        existingAlert.LastAlertSent = DateTime.UtcNow;
                        await SendLowStockNotificationAsync(product);
                    }
                }

                await _context.SaveChangesAsync();

                _logger.LogInformation($"Found {lowStockProducts.Count} low stock products");

                return new ServiceResponse<bool>
                {
                    Data = true,
                    Success = true,
                    Message = $"{lowStockProducts.Count} პროდუქტი დაბალი მარაგით"
                };
            }

            return new ServiceResponse<bool>
            {
                Data = false,
                Success = true,
                Message = "ყველა პროდუქტი საკმარისი რაოდენობითაა"
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error checking low stock");
            return new ServiceResponse<bool>
            {
                Success = false,
                Message = "შეცდომა მარაგების შემოწმებისას"
            };
        }
    }

    public async Task<ServiceResponse<bool>> SendOrderStatusUpdateAsync(int orderId, OrderStatus newStatus)
    {
        try
        {
            var order = await _context.Orders
                .Include(o => o.User)
                .FirstOrDefaultAsync(o => o.Id == orderId);

            if (order == null)
                return new ServiceResponse<bool> { Success = false, Message = "შეკვეთა ვერ მოიძებნა" };

            var statusMessage = newStatus switch
            {
                OrderStatus.Processing => "თქვენი შეკვეთა დამუშავების ეტაპზეა",
                OrderStatus.Shipped => "თქვენი შეკვეთა გაიგზავნა",
                OrderStatus.Delivered => "თქვენი შეკვეთა მიტანილია",
                OrderStatus.Cancelled => "თქვენი შეკვეთა გაუქმდა",
                _ => "შეკვეთის სტატუსი განახლდა"
            };

            var emailSent = await _emailService.SendEmailAsync(
                order.User.Email,
                $"შეკვეთის სტატუსის განახლება - #{order.Id}",
                $"გამარჯობა {order.User.Name},\n\n{statusMessage}\n\nშეკვეთის ID: {order.Id}\nსაერთო თანხა: {order.TotalAmount:C}\n\nმადლობა!"
            );

            return new ServiceResponse<bool>
            {
                Data = emailSent.Success,
                Success = emailSent.Success,
                Message = emailSent.Success ? "შეტყობინება გაიგზავნა" : emailSent.Message
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error sending order status update");
            return new ServiceResponse<bool>
            {
                Success = false,
                Message = "შეცდომა შეტყობინების გაგზავნისას"
            };
        }
    }

    public async Task<ServiceResponse<bool>> SendWelcomeEmailAsync(int userId)
    {
        try
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null)
                return new ServiceResponse<bool> { Success = false, Message = "მომხმარებელი ვერ მოიძებნა" };

            var emailSent = await _emailService.SendEmailAsync(
                user.Email,
                "მოგესალმებით ჩვენს ონლაინ მაღაზიაში!",
                $"გამარჯობა {user.Name ?? user.Username},\n\n" +
                "მოგესალმებით ჩვენს ელექტრონული კომერციის პლატფორმაზე!\n\n" +
                "ახლა შეგიძლიათ:\n" +
                "• იყიდოთ ათასობით პროდუქტი\n" +
                "• შექმნათ სურვილების სია\n" +
                "• თვალი ადევნოთ შეკვეთებს\n" +
                "• იღებდეთ სპეციალურ შეთავაზებებს\n\n" +
                "მადლობა რომ ჩვენ აირჩიეთ!"
            );

            return new ServiceResponse<bool>
            {
                Data = emailSent.Success,
                Success = emailSent.Success,
                Message = emailSent.Success ? "მისალმების ემაილი გაიგზავნა" : emailSent.Message
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error sending welcome email");
            return new ServiceResponse<bool>
            {
                Success = false,
                Message = "შეცდომა მისალმების ემაილის გაგზავნისას"
            };
        }
    }

    private async Task SendLowStockNotificationAsync(Product product)
    {
        try
        {
            // Get admin users
            var adminUsers = await _context.Users
                .Where(u => u.UserRole == UserRole.Admin || u.UserRole == UserRole.Manager)
                .ToListAsync();

            foreach (var admin in adminUsers)
            {
                await _emailService.SendEmailAsync(
                    admin.Email,
                    "დაბალი მარაგის გაფრთხილება",
                    $"გაფრთხილება!\n\n" +
                    $"პროდუქტი: {product.Name}\n" +
                    $"კატეგორია: {product.Category?.Name}\n" +
                    $"დარჩენილი რაოდენობა: {product.StockQuantity}\n" +
                    $"ფასი: {product.Price:C}\n\n" +
                    "გთხოვთ, შეავსოთ მარაგები."
                );
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error sending low stock notification");
        }
    }
}

