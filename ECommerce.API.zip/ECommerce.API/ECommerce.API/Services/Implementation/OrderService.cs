﻿using AutoMapper;
using ECommerce.API.Data;
using ECommerce.API.DTOs;
using ECommerce.API.Models;
using ECommerce.API.Models.Enums;
using ECommerce.API.Services.Interfaces;
using Microsoft.EntityFrameworkCore;
using ECommerce.API.Helpers;

namespace ECommerce.API.Services.Implementation;

public class OrderService : IOrderService
{
    private readonly AppDbContext _context;
    private readonly IMapper _mapper;

    public OrderService(AppDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<ServiceResponse<OrderDTO>> PlaceOrderAsync(int userId, CreateOrderDTO dto)
    {
        var response = new ServiceResponse<OrderDTO>();

        var cart = await _context.Carts
            .Include(c => c.Items)
            .ThenInclude(ci => ci.Product)
            .FirstOrDefaultAsync(c => c.UserId == userId);

        if (cart == null || !cart.Items.Any())
        {
            response.Success = false;
            response.Message = "კალათა ცარიელია";
            return response;
        }

        var order = new Order
        {
            UserId = userId,
            ShippingAddress = dto.ShippingAddress,
            PaymentMethod = dto.PaymentMethod,
            Status = OrderStatus.Pending
        };

        foreach (var item in cart.Items)
        {
            // Check stock availability
            if (item.Product.StockQuantity < item.Quantity)
            {
                response.Success = false;
                response.Message = $"პროდუქტი '{item.Product.Name}' არასაკმარისი რაოდენობითაა";
                return response;
            }

            order.Items.Add(new OrderItem
            {
                ProductId = item.ProductId,
                Quantity = item.Quantity,
                UnitPrice = item.Product.Price
            });

            // Update stock
            item.Product.StockQuantity -= item.Quantity;
        }

        order.TotalAmount = order.Items.Sum(oi => oi.Quantity * oi.UnitPrice);

        _context.Orders.Add(order);
        _context.CartItems.RemoveRange(cart.Items); // Clear cart

        await _context.SaveChangesAsync();

        response.Data = _mapper.Map<OrderDTO>(order);
        response.Message = "შეკვეთა წარმატებით შეიქმნა";
        return response;
    }

    public async Task<ServiceResponse<OrderDTO>> GetOrderByIdAsync(int id)
    {
        var response = new ServiceResponse<OrderDTO>();

        var order = await _context.Orders
            .Include(o => o.Items)
            .ThenInclude(i => i.Product)
            .FirstOrDefaultAsync(o => o.Id == id);

        if (order == null)
        {
            response.Success = false;
            response.Message = "შეკვეთა ვერ მოიძებნა";
            return response;
        }

        response.Data = _mapper.Map<OrderDTO>(order);
        return response;
    }

    public async Task<ServiceResponse<List<OrderDTO>>> GetOrdersByUserAsync(int userId)
    {
        var response = new ServiceResponse<List<OrderDTO>>();

        var orders = await _context.Orders
            .Include(o => o.Items)
            .ThenInclude(i => i.Product)
            .Where(o => o.UserId == userId)
            .OrderByDescending(o => o.CreatedAt)
            .ToListAsync();

        response.Data = _mapper.Map<List<OrderDTO>>(orders);
        return response;
    }

    public async Task<ServiceResponse<OrderDTO>> UpdateStatusAsync(int orderId, OrderStatus status)
    {
        var response = new ServiceResponse<OrderDTO>();

        var order = await _context.Orders.FindAsync(orderId);
        if (order == null)
        {
            response.Success = false;
            response.Message = "შეკვეთა ვერ მოიძებნა";
            return response;
        }

        order.Status = status;
        order.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();

        response.Data = _mapper.Map<OrderDTO>(order);
        response.Message = "შეკვეთის სტატუსი განახლდა";
        return response;
    }

    // Additional methods required by controller
    public async Task<ServiceResponse<OrderDTO>> PlaceOrderAsync(int userId)
    {
        // Place order with default shipping info from user profile
        var user = await _context.Users.FindAsync(userId);
        if (user == null)
        {
            return new ServiceResponse<OrderDTO> { Success = false, Message = "მომხმარებელი ვერ მოიძებნა" };
        }

        var defaultOrder = new CreateOrderDTO
        {
            ShippingAddress = "Default Address", // Can be improved
            PaymentMethod = "Cash"
        };

        return await PlaceOrderAsync(userId, defaultOrder);
    }

    public async Task<ServiceResponse<OrderDTO>> GetUserOrderAsync(int userId, int orderId)
    {
        var response = new ServiceResponse<OrderDTO>();

        var order = await _context.Orders
            .Include(o => o.Items)
            .ThenInclude(i => i.Product)
            .FirstOrDefaultAsync(o => o.Id == orderId && o.UserId == userId);

        if (order == null)
        {
            response.Success = false;
            response.Message = "შეკვეთა ვერ მოიძებნა";
            return response;
        }

        response.Data = _mapper.Map<OrderDTO>(order);
        return response;
    }

    public async Task<ServiceResponse<List<OrderDTO>>> GetUserOrdersAsync(int userId)
    {
        return await GetOrdersByUserAsync(userId);
    }

    public async Task<ServiceResponse<List<OrderDTO>>> GetAllOrdersAsync()
    {
        var response = new ServiceResponse<List<OrderDTO>>();

        var orders = await _context.Orders
            .Include(o => o.Items)
            .ThenInclude(i => i.Product)
            .Include(o => o.User)
            .OrderByDescending(o => o.CreatedAt)
            .ToListAsync();

        response.Data = _mapper.Map<List<OrderDTO>>(orders);
        return response;
    }

    public async Task<ServiceResponse<OrderDTO>> UpdateOrderStatusAsync(int orderId, OrderStatus status)
    {
        return await UpdateStatusAsync(orderId, status);
    }
}
