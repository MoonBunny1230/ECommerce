﻿using ECommerce.API.DTOs;
using ECommerce.API.Helpers;
using ECommerce.API.Services.Interfaces;

namespace ECommerce.API.Services.Implementation;

public class PaymentService : IPaymentService
{
    private readonly IConfiguration _configuration;
    private readonly ILogger<PaymentService> _logger;

    public PaymentService(IConfiguration configuration, ILogger<PaymentService> logger)
    {
        _configuration = configuration;
        _logger = logger;
    }

    public async Task<ServiceResponse<PaymentResultDTO>> ProcessPaymentAsync(PaymentRequestDTO request)
    {
        try
        {
            var isTestMode = _configuration.GetValue<bool>("Payment:EnableTestMode", true);

            if (isTestMode)
            {
                return await ProcessMockPaymentAsync(request);
            }
            else
            {
                // Real payment processing would go here
                // Integration with TBC Bank, Bank of Georgia, etc.
                return await ProcessRealPaymentAsync(request);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing payment for order {OrderId}", request.OrderId);
            return new ServiceResponse<PaymentResultDTO>
            {
                Success = false,
                Message = "გადახდის დამუშავებისას მოხდა შეცდომა",
                Data = new PaymentResultDTO
                {
                    Success = false,
                    TransactionId = null,
                    ErrorMessage = ex.Message,
                    Amount = request.Amount,
                    Currency = request.Currency,
                    PaymentMethod = request.PaymentMethod,
                    ProcessedAt = DateTime.UtcNow
                }
            };
        }
    }

    public async Task<ServiceResponse<PaymentStatusDTO>> GetPaymentStatusAsync(string transactionId)
    {
        try
        {
            var isTestMode = _configuration.GetValue<bool>("Payment:EnableTestMode", true);

            if (isTestMode)
            {
                // Mock implementation
                await Task.Delay(100);

                var status = transactionId.StartsWith("fail_") ? "Failed" :
                           transactionId.StartsWith("pending_") ? "Pending" : "Success";

                return new ServiceResponse<PaymentStatusDTO>
                {
                    Success = true,
                    Data = new PaymentStatusDTO
                    {
                        TransactionId = transactionId,
                        Status = status,
                        Amount = 0, // In real implementation, fetch from payment provider
                        ProcessedAt = DateTime.UtcNow
                    }
                };
            }
            else
            {
                // Real payment status check would go here
                return await GetRealPaymentStatusAsync(transactionId);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting payment status for transaction {TransactionId}", transactionId);
            return new ServiceResponse<PaymentStatusDTO>
            {
                Success = false,
                Message = "გადახდის სტატუსის მიღებისას მოხდა შეცდომა"
            };
        }
    }

    public async Task<ServiceResponse<RefundResultDTO>> RefundPaymentAsync(RefundRequestDTO request)
    {
        try
        {
            var isTestMode = _configuration.GetValue<bool>("Payment:EnableTestMode", true);

            if (isTestMode)
            {
                return await ProcessMockRefundAsync