﻿using AutoMapper;
using ECommerce.API.Data;
using ECommerce.API.DTOs;
using ECommerce.API.Helpers;
using ECommerce.API.Models;
using ECommerce.API.Models.Enums;
using ECommerce.API.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace ECommerce.API.Services.Implementation
{
    public class ProductService : IProductService
    {
        private readonly AppDbContext _context;
        private readonly IMapper _mapper;

        public ProductService(AppDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<ServiceResponse<PaginatedResultDTO<ProductDTO>>> GetProductsAsync(ProductFilterDTO filter)
        {
            var query = _context.Products
                .Include(p => p.Category)
                .Include(p => p.Comments)
                .Where(p => p.Status == ProductStatus.Active)
                .AsQueryable();

            // Apply filters
            if (filter.CategoryId.HasValue)
                query = query.Where(p => p.CategoryId == filter.CategoryId.Value);

            if (filter.CategoryIds?.Any() == true)
                query = query.Where(p => filter.CategoryIds.Contains(p.CategoryId));

            if (filter.MinPrice.HasValue)
                query = query.Where(p => p.Price >= filter.MinPrice.Value);

            if (filter.MaxPrice.HasValue)
                query = query.Where(p => p.Price <= filter.MaxPrice.Value);

            if (filter.InStock == true)
                query = query.Where(p => p.StockQuantity > 0);

            if (filter.HasDiscount == true)
                query = query.Where(p => p.DiscountPercentage.HasValue &&
                                        p.DiscountExpiresAt.HasValue &&
                                        p.DiscountExpiresAt > DateTime.UtcNow);

            if (filter.MinRating.HasValue)
                query = query.Where(p => p.Comments.Any() &&
                                        p.Comments.Average(c => c.Rating) >= filter.MinRating.Value);

            if (!string.IsNullOrEmpty(filter.SearchQuery))
            {
                var searchTerm = filter.SearchQuery.ToLower();
                query = query.Where(p => p.Name.ToLower().Contains(searchTerm) ||
                                       p.Description.ToLower().Contains(searchTerm) ||
                                       p.Category.Name.ToLower().Contains(searchTerm));
            }

            // Apply sorting
            query = filter.SortBy?.ToLower() switch
            {
                "price" => filter.SortDesc ?
                    query.OrderByDescending(p => p.Price) :
                    query.OrderBy(p => p.Price),
                "rating" => filter.SortDesc ?
                    query.OrderByDescending(p => p.Comments.Any() ? p.Comments.Average(c => c.Rating) : 0) :
                    query.OrderBy(p => p.Comments.Any() ? p.Comments.Average(c => c.Rating) : 0),
                "date" => filter.SortDesc ?
                    query.OrderByDescending(p => p.CreatedAt) :
                    query.OrderBy(p => p.CreatedAt),
                "popularity" => filter.SortDesc ?
                    query.OrderByDescending(p => p.OrderItems.Sum(oi => oi.Quantity)) :
                    query.OrderBy(p => p.OrderItems.Sum(oi => oi.Quantity)),
                _ => filter.SortDesc ?
                    query.OrderByDescending(p => p.Name) :
                    query.OrderBy(p => p.Name)
            };

            var totalCount = await query.CountAsync();

            var products = await query
                .Skip((filter.PageNumber - 1) * filter.PageSize)
                .Take(filter.PageSize)
                .ToListAsync();

            var productDtos = _mapper.Map<List<ProductDTO>>(products);

            return new ServiceResponse<PaginatedResultDTO<ProductDTO>>
            {
                Data = new PaginatedResultDTO<ProductDTO>
                {
                    Data = productDtos,
                    TotalCount = totalCount,
                    PageNumber = filter.PageNumber,
                    PageSize = filter.PageSize
                },
                Success = true,
                Message = "პროდუქტები წარმატებით მოძიებულია."
            };
        }

        public async Task<ServiceResponse<List<MonthlySalesDTO>>> GetAllAsync()
        {
            var products = await _context.Products
                .Include(p => p.Category)
                .Include(p => p.Comments)
                .ToListAsync();

            var productDtos = _mapper.Map<List<MonthlySalesDTO>>(products);
            return new ServiceResponse<List<MonthlySalesDTO>> { Data = productDtos, Success = true };
        }

        public async Task<ServiceResponse<ProductDTO>> AddProductAsync(CreateProductDTO createDto)
        {
            var product = _mapper.Map<Product>(createDto);
            product.Status = ProductStatus.Active;
            product.CreatedAt = DateTime.UtcNow;
            product.UpdatedAt = DateTime.UtcNow;

            _context.Products.Add(product);
            await _context.SaveChangesAsync();

            await _context.Entry(product).Reference(p => p.Category).LoadAsync();

            return new ServiceResponse<ProductDTO>
            {
                Data = _mapper.Map<ProductDTO>(product),
                Success = true,
                Message = "პროდუქტი წარმატებით დაემატა."
            };
        }

        public async Task<ServiceResponse<MonthlySalesDTO>> AddProductAsync(MonthlySalesDTO productDto)
        {
            var product = _mapper.Map<Product>(productDto);
            product.Status = ProductStatus.Active;
            product.CreatedAt = DateTime.UtcNow;
            product.UpdatedAt = DateTime.UtcNow;

            _context.Products.Add(product);
            await _context.SaveChangesAsync();

            await _context.Entry(product).Reference(p => p.Category).LoadAsync();

            return new ServiceResponse<MonthlySalesDTO>
            {
                Data = _mapper.Map<MonthlySalesDTO>(product),
                Success = true,
                Message = "პროდუქტი წარმატებით დაემატა."
            };
        }

        public async Task<ServiceResponse<ProductDTO>> UpdateAsync(int id, UpdateProductDTO updateDto)
        {
            var product = await _context.Products
                .Include(p => p.Category)
                .FirstOrDefaultAsync(p => p.Id == id);

            if (product == null)
                return new ServiceResponse<ProductDTO> { Success = false, Message = "პროდუქტი ვერ მოიძებნა." };

            product.Name = updateDto.Name;
            product.Description = updateDto.Description;
            product.Price = updateDto.Price;
            product.StockQuantity = updateDto.StockQuantity;
            product.CategoryId = updateDto.CategoryId;
            product.Images = updateDto.Images;
            product.DiscountPercentage = updateDto.DiscountPercentage;
            product.DiscountExpiresAt = updateDto.DiscountExpiresAt;
            product.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            return new ServiceResponse<ProductDTO>
            {
                Data = _mapper.Map<ProductDTO>(product),
                Success = true,
                Message = "პროდუქტი წარმატებით განახლდა."
            };
        }

        public async Task<ServiceResponse<MonthlySalesDTO>> UpdateAsync(int id, UpdateProductDTO updateDto)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
                return new ServiceResponse<MonthlySalesDTO> { Success = false, Message = "პროდუქტი ვერ მოიძებნა." };

            product.Name = updateDto.Name;
            product.Description = updateDto.Description;
            product.Price = updateDto.Price;
            product.StockQuantity = updateDto.StockQuantity;
            product.CategoryId = updateDto.CategoryId;
            product.DiscountPercentage = updateDto.DiscountPercentage;
            product.DiscountExpiresAt = updateDto.DiscountExpiresAt;
            product.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            await _context.Entry(product).Reference(p => p.Category).LoadAsync();

            return new ServiceResponse<MonthlySalesDTO>
            {
                Data = _mapper.Map<MonthlySalesDTO>(product),
                Success = true,
                Message = "პროდუქტი წარმატებით განახლდა."
            };
        }

        public async Task<ServiceResponse<bool>> DeleteProductAsync(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
                return new ServiceResponse<bool> { Success = false, Message = "პროდუქტი ვერ მოიძებნა." };

            // Don't actually delete, just mark as inactive
            product.Status = ProductStatus.Inactive;
            product.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            return new ServiceResponse<bool> { Data = true, Success = true, Message = "პროდუქტი წარმატებით წაიშალა." };
        }

        public async Task<ServiceResponse<ProductDTO>> GetProductByIdAsync(int id)
        {
            var product = await _context.Products
                .Include(p => p.Category)
                .Include(p => p.Comments)
                    .ThenInclude(c => c.User)
                .FirstOrDefaultAsync(p => p.Id == id && p.Status == ProductStatus.Active);

            if (product == null)
                return new ServiceResponse<ProductDTO> { Success = false, Message = "პროდუქტი ვერ მოიძებნა." };

            return new ServiceResponse<ProductDTO> { Data = _mapper.Map<ProductDTO>(product), Success = true };
        }

        public async Task<ServiceResponse<MonthlySalesDTO>> GetProductByIdAsync(int id)
        {
            var product = await _context.Products
                .Include(p => p.Category)
                .FirstOrDefaultAsync(p => p.Id == id);

            if (product == null)
                return new ServiceResponse<MonthlySalesDTO> { Success = false, Message = "პროდუქტი ვერ მოიძებნა." };

            return new ServiceResponse<MonthlySalesDTO> { Data = _mapper.Map<MonthlySalesDTO>(product), Success = true };
        }

        public async Task<ServiceResponse<MonthlySalesDTO>> UpdateProductAsync(int id, MonthlySalesDTO productDto)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
                return new ServiceResponse<MonthlySalesDTO> { Success = false, Message = "პროდუქტი ვერ მოიძებნა." };

            _mapper.Map(productDto, product);
            product.UpdatedAt = DateTime.UtcNow;
            await _context.SaveChangesAsync();

            await _context.Entry(product).Reference(p => p.Category).LoadAsync();
            return new ServiceResponse<MonthlySalesDTO>
            {
                Data = _mapper.Map<MonthlySalesDTO>(product),
                Success = true,
                Message = "პროდუქტი წარმატებით განახლდა."
            };
        }

        // Additional helper methods
        public async Task<ServiceResponse<List<ProductDTO>>> GetFeaturedProductsAsync(int count = 8)
        {
            var products = await _context.Products
                .Include(p => p.Category)
                .Include(p => p.Comments)
                .Where(p => p.Status == ProductStatus.Active)
                .OrderByDescending(p => p.Comments.Any() ? p.Comments.Average(c => c.Rating) : 0)
                .Take(count)
                .ToListAsync();

            var productDtos = _mapper.Map<List<ProductDTO>>(products);
            return new ServiceResponse<List<ProductDTO>> { Data = productDtos, Success = true };
        }

        public async Task<ServiceResponse<List<ProductDTO>>> GetLatestProductsAsync(int count = 8)
        {
            var products = await _context.Products
                .Include(p => p.Category)
                .Include(p => p.Comments)
                .Where(p => p.Status == ProductStatus.Active)
                .OrderByDescending(p => p.CreatedAt)
                .Take(count)
                .ToListAsync();

            var productDtos = _mapper.Map<List<ProductDTO>>(products);
            return new ServiceResponse<List<ProductDTO>> { Data = productDtos, Success = true };
        }
    }
}