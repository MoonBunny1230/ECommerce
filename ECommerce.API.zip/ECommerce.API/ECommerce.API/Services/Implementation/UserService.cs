﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using ECommerce.API.Data;
using ECommerce.API.DTOs;
using ECommerce.API.Helpers;
using ECommerce.API.Models;
using ECommerce.API.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace ECommerce.API.Services.Implementation;

public class UserService : IUserService
{
    private readonly AppDbContext _context;
    private readonly IMapper _mapper;

    public UserService(AppDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<ServiceResponse<UserDTO>> GetUserByIdAsync(int id)
    {
        var response = new ServiceResponse<UserDTO>();

        var user = await _context.Users.FindAsync(id);
        if (user == null)
        {
            response.Success = false;
            response.Message = "მომხმარებელი ვერ მოიძებნა";
            return response;
        }

        response.Data = _mapper.Map<UserDTO>(user);
        return response;
    }

    public async Task<ServiceResponse<UserDTO>> UpdateUserAsync(int id, UserDTO dto)
    {
        var response = new ServiceResponse<UserDTO>();

        var user = await _context.Users.FindAsync(id);
        if (user == null)
        {
            response.Success = false;
            response.Message = "მომხმარებელი ვერ მოიძებნა";
            return response;
        }

        user.Name = dto.Name;
        user.Email = dto.Email;
        user.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();

        response.Data = _mapper.Map<UserDTO>(user);
        response.Message = "მომხმარებელი განახლდა";
        return response;
    }

    public async Task<ServiceResponse<List<OrderDTO>>> GetUserOrdersAsync(int userId)
    {
        var response = new ServiceResponse<List<OrderDTO>>();

        var orders = await _context.Orders
            .Include(o => o.Items)
            .ThenInclude(i => i.Product)
            .Where(o => o.UserId == userId)
            .OrderByDescending(o => o.CreatedAt)
            .ToListAsync();

        response.Data = _mapper.Map<List<OrderDTO>>(orders);
        return response;
    }

    public async Task<ServiceResponse<List<UserDTO>>> GetAllUsersAsync()
    {
        var response = new ServiceResponse<List<UserDTO>>();

        var users = await _context.Users.ToListAsync();
        response.Data = _mapper.Map<List<UserDTO>>(users);
        return response;
    }

    public async Task<ServiceResponse<bool>> DeleteUserAsync(int id)
    {
        var response = new ServiceResponse<bool>();

        var user = await _context.Users.FindAsync(id);
        if (user == null)
        {
            response.Success = false;
            response.Message = "მომხმარებელი ვერ მოიძებნა";
            return response;
        }

        _context.Users.Remove(user);
        await _context.SaveChangesAsync();

        response.Data = true;
        response.Message = "მომხმარებელი წაიშალა";
        return response;
    }
}