﻿using AutoMapper;
using ECommerce.API.Data;
using ECommerce.API.DTOs;
using ECommerce.API.Helpers;
using ECommerce.API.Models;
using ECommerce.API.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace ECommerce.API.Services.Implementation;

public class WishlistService : IWishlistService
{
    private readonly AppDbContext _context;
    private readonly IMapper _mapper;

    public WishlistService(AppDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<ServiceResponse<List<WishlistDTO>>> GetUserWishlistAsync(int userId)
    {
        var wishlistItems = await _context.Wishlists
            .Include(w => w.Product)
            .Where(w => w.UserId == userId)
            .OrderByDescending(w => w.CreatedAt)
            .ToListAsync();

        var wishlistDtos = wishlistItems.Select(w => new WishlistDTO
        {
            Id = w.Id,
            ProductId = w.ProductId,
            ProductName = w.Product.Name,
            Price = w.Product.Price,
            Image = w.Product.Images,
            CreatedAt = w.CreatedAt
        }).ToList();

        return new ServiceResponse<List<WishlistDTO>>
        {
            Data = wishlistDtos,
            Success = true,
            Message = "სურვილების სია წარმატებით მოძიებულია"
        };
    }

    public async Task<ServiceResponse<bool>> AddToWishlistAsync(int userId, int productId)
    {
        // Check if product exists
        var productExists = await _context.Products.AnyAsync(p => p.Id == productId);
        if (!productExists)
            return new ServiceResponse<bool> { Success = false, Message = "პროდუქტი ვერ მოიძებნა" };

        // Check if already in wishlist
        var existingItem = await _context.Wishlists
            .FirstOrDefaultAsync(w => w.UserId == userId && w.ProductId == productId);

        if (existingItem != null)
            return new ServiceResponse<bool> { Success = false, Message = "პროდუქტი უკვე არის სურვილების სიაში" };

        var wishlistItem = new Wishlist
        {
            UserId = userId,
            ProductId = productId,
            CreatedAt = DateTime.UtcNow
        };

        _context.Wishlists.Add(wishlistItem);
        await _context.SaveChangesAsync();

        return new ServiceResponse<bool>
        {
            Data = true,
            Success = true,
            Message = "პროდუქტი დაემატა სურვილების სიაში"
        };
    }

    public async Task<ServiceResponse<bool>> RemoveFromWishlistAsync(int userId, int productId)
    {
        var wishlistItem = await _context.Wishlists
            .FirstOrDefaultAsync(w => w.UserId == userId && w.ProductId == productId);

        if (wishlistItem == null)
            return new ServiceResponse<bool> { Success = false, Message = "პროდუქტი სურვილების სიაში ვერ მოიძებნა" };

        _context.Wishlists.Remove(wishlistItem);
        await _context.SaveChangesAsync();

        return new ServiceResponse<bool>
        {
            Data = true,
            Success = true,
            Message = "პროდუქტი წაიშალა სურვილების სიიდან"
        };
    }

    public async Task<ServiceResponse<bool>> IsInWishlistAsync(int userId, int productId)
    {
        var exists = await _context.Wishlists
            .AnyAsync(w => w.UserId == userId && w.ProductId == productId);

        return new ServiceResponse<bool> { Data = exists, Success = true };
    }

    public async Task<ServiceResponse<bool>> ClearWishlistAsync(int userId)
    {
        var wishlistItems = await _context.Wishlists
            .Where(w => w.UserId == userId)
            .ToListAsync();

        _context.Wishlists.RemoveRange(wishlistItems);
        await _context.SaveChangesAsync();

        return new ServiceResponse<bool>
        {
            Data = true,
            Success = true,
            Message = "სურვილების სია გასუფთავდა"
        };
    }
}