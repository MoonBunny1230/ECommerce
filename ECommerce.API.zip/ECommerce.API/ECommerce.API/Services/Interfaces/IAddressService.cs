﻿using ECommerce.API.DTOs;
using ECommerce.API.Helpers;

public interface IAddressService
{
    Task<ServiceResponse<List<AddressDTO>>> GetUserAddressesAsync(int userId);
    Task<ServiceResponse<AddressDTO>> CreateAddressAsync(int userId, CreateAddressDTO dto);
    Task<ServiceResponse<AddressDTO>> UpdateAddressAsync(int userId, int addressId, AddressDTO dto);
    Task<ServiceResponse<bool>> DeleteAddressAsync(int userId, int addressId);
    Task<ServiceResponse<bool>> SetDefaultAddressAsync(int userId, int addressId);
    Task<ServiceResponse<AddressDTO>> GetDefaultAddressAsync(int userId);
}