﻿using ECommerce.API.DTOs;
using ECommerce.API.Helpers;

namespace ECommerce.API.Services.Interfaces;

public interface ICartService
{
    Task<ServiceResponse<CartDTO>> GetCartAsync(int userId);
    Task<ServiceResponse<CartDTO>> GetCartByUserIdAsync(int userId);
    Task<ServiceResponse<CartDTO>> AddItemAsync(int userId, CartItemDTO dto);
    Task<ServiceResponse<CartDTO>> AddItemToCartAsync(int userId, CartItemDTO dto);
    Task<ServiceResponse<CartDTO>> UpdateQuantityAsync(int userId, int itemId, int quantity);
    Task<ServiceResponse<CartDTO>> UpdateItemQuantityAsync(int userId, int itemId, int quantity);
    Task<ServiceResponse<bool>> RemoveItemAsync(int userId, int itemId);
    Task<ServiceResponse<bool>> RemoveItemFromCartAsync(int userId, int itemId);
    Task<ServiceResponse<bool>> ClearCartAsync(int userId);
}
