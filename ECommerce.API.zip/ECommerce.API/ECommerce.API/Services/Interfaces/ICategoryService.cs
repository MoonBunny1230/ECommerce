﻿using ECommerce.API.DTOs;
using ECommerce.API.Helpers;

namespace ECommerce.API.Services.Interfaces;

public interface ICategoryService
{
    Task<ServiceResponse<List<CategoryDTO>>> GetAllAsync();
    Task<ServiceResponse<CategoryDTO>> GetByIdAsync(int id);
    Task<ServiceResponse<CategoryDTO>> CreateAsync(CategoryDTO dto);
    Task<ServiceResponse<CategoryDTO>> AddAsync(CreateCategoryDTO dto);
    Task<ServiceResponse<CategoryDTO>> UpdateAsync(int id, CategoryDTO dto);
    Task<ServiceResponse<bool>> DeleteAsync(int id);
}