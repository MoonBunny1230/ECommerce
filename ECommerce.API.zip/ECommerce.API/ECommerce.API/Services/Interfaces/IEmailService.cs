﻿using ECommerce.API.Helpers;

namespace ECommerce.API.Services.Interfaces;

public interface IEmailService
{
    Task<ServiceResponse<bool>> SendEmailAsync(string toEmail, string subject, string body);
    Task<ServiceResponse<bool>> SendHtmlEmailAsync(string toEmail, string subject, string htmlBody);
}