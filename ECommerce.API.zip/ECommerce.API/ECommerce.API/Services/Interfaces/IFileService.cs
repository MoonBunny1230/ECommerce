﻿using ECommerce.API.Helpers;

namespace ECommerce.API.Services.Interfaces;

public interface IFileService
{
    Task<ServiceResponse<string>> UploadFileAsync(IFormFile file, string folder);
    Task<ServiceResponse<bool>> DeleteFileAsync(string fileName, string folder);
    Task<ServiceResponse<List<string>>> UploadMultipleFilesAsync(IFormFile[] files, string folder);
}