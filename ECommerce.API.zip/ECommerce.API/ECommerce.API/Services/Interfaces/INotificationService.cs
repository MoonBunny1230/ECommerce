﻿using ECommerce.API.Helpers;
using ECommerce.API.Models.Enums;

namespace ECommerce.API.Services.Interfaces;

public interface INotificationService
{
    Task<ServiceResponse<bool>> CheckLowStockAsync();
    Task<ServiceResponse<bool>> SendOrderStatusUpdateAsync(int orderId, OrderStatus newStatus);
    Task<ServiceResponse<bool>> SendWelcomeEmailAsync(int userId);
}