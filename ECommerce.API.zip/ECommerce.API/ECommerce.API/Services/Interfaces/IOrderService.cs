﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ECommerce.API.DTOs;
using ECommerce.API.Helpers;
using ECommerce.API.Models.Enums;

namespace ECommerce.API.Services.Interfaces;

public interface IOrderService
{
    Task<ServiceResponse<OrderDTO>> PlaceOrderAsync(int userId, CreateOrderDTO dto);
    Task<ServiceResponse<OrderDTO>> PlaceOrderAsync(int userId); // From cart
    Task<ServiceResponse<OrderDTO>> GetOrderByIdAsync(int id);
    Task<ServiceResponse<OrderDTO>> GetUserOrderAsync(int userId, int orderId);
    Task<ServiceResponse<List<OrderDTO>>> GetOrdersByUserAsync(int userId);
    Task<ServiceResponse<List<OrderDTO>>> GetUserOrdersAsync(int userId);
    Task<ServiceResponse<List<OrderDTO>>> GetAllOrdersAsync();
    Task<ServiceResponse<OrderDTO>> UpdateStatusAsync(int orderId, OrderStatus status);
    Task<ServiceResponse<OrderDTO>> UpdateOrderStatusAsync(int orderId, OrderStatus status);
}