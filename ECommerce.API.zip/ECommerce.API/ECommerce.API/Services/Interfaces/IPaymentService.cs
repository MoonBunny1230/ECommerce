﻿using ECommerce.API.Helpers;
using ECommerce.API.DTOs;

namespace ECommerce.API.Services.Interfaces
{
    public interface IPaymentService
    {
        Task<ServiceResponse<PaymentResultDTO>> ProcessPaymentAsync(PaymentRequestDTO request);
        Task<ServiceResponse<PaymentStatusDTO>> GetPaymentStatusAsync(string transactionId);
        Task<ServiceResponse<RefundRequestDTO>> RefundPaymentAsync(RefundRequestDTO request); // FIXED: RefundResultDTO instead of PaginatedResultDTO
    }
}