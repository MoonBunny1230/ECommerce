﻿using ECommerce.API.DTOs;
using ECommerce.API.Helpers;

namespace ECommerce.API.Services.Interfaces
{
    public interface IProductService
    {
        // Main CRUD operations
        Task<ServiceResponse<MonthlySalesDTO>> AddProductAsync(MonthlySalesDTO productDto);
        Task<ServiceResponse<ProductDTO>> AddProductAsync(CreateProductDTO createDto); // ADDED
        Task<ServiceResponse<ProductDTO>> GetProductByIdAsync(int id); // CHANGED return type
        Task<ServiceResponse<MonthlySalesDTO>> GetProductByIdAsync(int id); // Keep for backwards compatibility
        Task<ServiceResponse<PaginatedResultDTO<ProductDTO>>> GetProductsAsync(ProductFilterDTO filter); // ENHANCED
        Task<ServiceResponse<List<MonthlySalesDTO>>> GetAllAsync(); // For admin
        Task<ServiceResponse<ProductDTO>> UpdateAsync(int id, UpdateProductDTO updateDto); // CHANGED return type
        Task<ServiceResponse<MonthlySalesDTO>> UpdateAsync(int id, UpdateProductDTO updateDto); // Keep for compatibility
        Task<ServiceResponse<MonthlySalesDTO>> UpdateProductAsync(int id, MonthlySalesDTO productDto);
        Task<ServiceResponse<bool>> DeleteProductAsync(int id);

        // Additional methods
        Task<ServiceResponse<List<ProductDTO>>> GetFeaturedProductsAsync(int count = 8); // ADDED
        Task<ServiceResponse<List<ProductDTO>>> GetLatestProductsAsync(int count = 8); // ADDED
    }
}