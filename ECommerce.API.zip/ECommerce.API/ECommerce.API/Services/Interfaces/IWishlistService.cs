﻿using ECommerce.API.DTOs;
using ECommerce.API.Helpers;

namespace ECommerce.API.Services.Interfaces;

public interface IWishlistService
{
    Task<ServiceResponse<List<WishlistDTO>>> GetUserWishlistAsync(int userId);
    Task<ServiceResponse<bool>> AddToWishlistAsync(int userId, int productId);
    Task<ServiceResponse<bool>> RemoveFromWishlistAsync(int userId, int productId);
    Task<ServiceResponse<bool>> IsInWishlistAsync(int userId, int productId);
    Task<ServiceResponse<bool>> ClearWishlistAsync(int userId);
}